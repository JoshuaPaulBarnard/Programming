/*
Joshua P. Barnard
jpb68@humboldt.edu
04/06/2018
A9 - Merge and Graph Data Using SQL
CS 17.11 - Spring 2018

 */

package edu.srjc.Barnard.Joshua.A9.Merge_and_Graph_Data_Using_SQL;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import edu.srjc.Barnard.Joshua.A9.Merge_and_Graph_Data_Using_SQL.Readers.Gas_Reader;
import edu.srjc.Barnard.Joshua.A9.Merge_and_Graph_Data_Using_SQL.Histories.Gas_History;
import edu.srjc.Barnard.Joshua.A9.Merge_and_Graph_Data_Using_SQL.Readers.Electric_Reader;
import edu.srjc.Barnard.Joshua.A9.Merge_and_Graph_Data_Using_SQL.Histories.Electric_History;
import edu.srjc.Barnard.Joshua.A9.Merge_and_Graph_Data_Using_SQL.Readers.Temperature_Reader;
import edu.srjc.Barnard.Joshua.A9.Merge_and_Graph_Data_Using_SQL.Histories.Temperature_History;


public class HomeDataPoint
{
    /*
    HashMap<String, Double> gas_Map = new HashMap<>();

    public void setGas_Map( Gas_History gas_history )
    {
        for( Gas_Reader currentReading : gas_history )
        {
            gasMap.put( currentReading.getDate(), Double.parseDouble( currentReading.getGasUsage() ) );
        }
    }
    */

        /*
    HashMap<String, Double> electric_Map = new HashMap<>();

    public void setElectric_Map( Electric_History electric_history )
    {
        for( Electric_Reader currentReading : electric_history )
        {
            Electric_Map.put( currentReading.getDate(), Double.parseDouble( currentReading.getGasUsage() ) );
        }
    }
    */

            /*
    HashMap<String, Double> temperature_Map = new HashMap<>();

    public void setTemperature_Map( Temperature_History temperature_history )
    {
        for( Temperature_Reader currentReading : temperature_history )
        {
            gasMap.put( currentReading.getDate(), Double.parseDouble( currentReading.getGasUsage() ) );
        }
    }
    */

                /*
    HashMap<String, Double> dateMap = new HashMap<>();


    */
}

