package edu.srjc.beanie;


import java.util.Scanner;

public class Main {

    public static void main(String[] args)
    {

        String whoTheHeckAreYou;

        Scanner kbd = new Scanner(System.in);

        System.out.print("What is your name? ");

        whoTheHeckAreYou = kbd.nextLine();

        System.out.println("Hello " + whoTheHeckAreYou);

    }
}
