package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Player;

public class Player
{
    // Players Information
    public static String playersName = "";
    public static boolean isMale = true;
    public static String playersClass = "";
    public static String playersColour = "";

    // Players Statistics
    public int HealthPoints = 0;
    public int WillPoints = 0;
    public int ExperiencePoints = 0;
    public int playersLevel = 0;

    // Players Attributes
    public int Courage = 0;
    public int Resolve = 0;
    public int Stamina = 0;
    public int Resilience = 0;
    public int Charisma = 0;
    public int Presense = 0;
    public int Perception = 0;
    public int Sense = 0;
    public int Agility = 0;
    public int Reflexes = 0;
    public int Intelligence = 0;
    public int Knowledge = 0;
    public int Wisdom = 0;
    public int Will = 0;
    public int Psyche = 0;



}
