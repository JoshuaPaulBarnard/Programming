package edu.srjc.seank.SIS.Students;

import edu.srjc.seank.SIS.AgeGreaterThan125Exception;
import edu.srjc.seank.SIS.AgeLessThanZeroException;
import edu.srjc.seank.SIS.Person;

public class Student extends Person
{
    public Student(String firstName, String lastName, String address, String city, String state, String zip, int age, String id) throws AgeLessThanZeroException, AgeGreaterThan125Exception
    {
        super(firstName, lastName, address, city, state, zip, age);
        this.id = id;
    }

    private String id;

    public Student()
    {
        super();

    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }
}
