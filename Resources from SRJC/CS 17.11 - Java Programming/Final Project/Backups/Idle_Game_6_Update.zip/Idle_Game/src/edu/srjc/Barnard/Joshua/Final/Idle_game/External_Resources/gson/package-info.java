/**
 * This package provides the {@link edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.Gson} class to convert Json to Java and
 * vice-versa.
 *
 * <p>The primary class to use is {@link edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.Gson} which can be constructed with
 * {@code new gson()} (using default settings) or by using {@link edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.GsonBuilder}
 * (to configure various options such as using versioning and so on).</p>
 *
 * @author Inderjeet Singh, Joel Leitch
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson;