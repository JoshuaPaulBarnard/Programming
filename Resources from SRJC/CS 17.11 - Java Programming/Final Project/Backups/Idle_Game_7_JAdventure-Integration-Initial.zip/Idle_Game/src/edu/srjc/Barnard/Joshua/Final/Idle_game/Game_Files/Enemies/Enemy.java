/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Enemies;

import java.util.List;
import java.util.Arrays;
import java.util.Random;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Entities.Entity;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Items.Item;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.GameBeans;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Repository.Item_Repository;



/*
 * This class just holds a type of enemy that is
 * further outlined in its respective file. For now it
 * just holds the enemy's name.
 */
public abstract class Enemy extends Entity {
    public String enemyType;
    private int xpGain;
    private Item_Repository itemRepo = GameBeans.getItemRepository();

    public int getXPGain() {
        return xpGain;
    }

    public void setXPGain(int xpGain) {
        this.xpGain = xpGain;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof Enemy) {
            Enemy m = (Enemy) obj;
            return m.enemyType.equals(this.enemyType);
        }
        return false;
    }

    public void addRandomItems(int playerLevel, String... children) {
        List<String> itemList = Arrays.asList(children);
        Random rand = new Random();

        int numItems = 1;
        int i = 0;
        while (i != numItems) {
            for (String itemName : itemList) {
                if (i == numItems) {
                    break;
                }

                int j = rand.nextInt(5) + 1;
                if (j == 1) {
                    Item item = itemRepo.getItem(itemName);
                    addItemToStorage(item);
                    i++;
                }
            }
        }
    }
}
