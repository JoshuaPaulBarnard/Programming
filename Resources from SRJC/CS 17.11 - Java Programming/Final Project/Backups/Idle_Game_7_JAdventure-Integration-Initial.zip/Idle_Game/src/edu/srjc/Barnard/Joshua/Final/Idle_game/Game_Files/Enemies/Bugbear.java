/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */


package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Enemies;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Items.ItemStack;

/*
 * A hybrid animal with the matching armour and high damage, but low health.
 */
public class Bugbear extends Enemy
{
    public Bugbear(int playerLevel)
    {
        this.enemyType = "Bugbear";
        this.setHealthMax(50 + playerLevel * 5);
        this.setHealth(50 + playerLevel * 5);
        this.setArmour(playerLevel);
        this.setDamage(10 + playerLevel * 2);
        this.setIntelligence(1);
        this.setStealth(1);
        this.setDexterity(1);
        this.setCritChance(0.02);
        this.setXPGain(30 + playerLevel * 3);
        this.setGold(playerLevel * 3);
        addRandomItems(playerLevel, "fram1", "pmil1");
    }
}

