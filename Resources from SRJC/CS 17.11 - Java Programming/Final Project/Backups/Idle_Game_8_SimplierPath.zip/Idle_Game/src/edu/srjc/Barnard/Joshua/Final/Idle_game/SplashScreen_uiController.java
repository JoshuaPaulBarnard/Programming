package edu.srjc.Barnard.Joshua.Final.Idle_game;

public class SplashScreen_uiController
{

}
