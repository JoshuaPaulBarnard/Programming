/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Navigation;


import java.util.List;
import java.util.Map;

import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Entities.NPC;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Items.Item;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Items.Storage;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Enemies.Enemy;



/**
 * This interface maps all the properties and methods that
 * pertain to a specific location.
 */
public interface Current_Location {
    Coordinate getCoordinate();
    String getTitle();
    String getDescription();
    Location_Type getLocationType();

    List<Item> getItems();
    Storage getStorage();

    void addItem(Item item);
    Item removeItem(Item item);

    List<NPC> getNpcs();
    List<Enemy> getMonsters();

    void addMonster(Enemy enemy);
    void removeMonster(Enemy enemy);

    void addNpcs(List<String> npcIds);
    void addNpc(String npcID);
    void removeNpc(NPC npc);

    int getDangerRating();
    void setDangerRating(int dangerRating);

    Map<Direction, Current_Location> getExits();
    void print();
}

