/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Enemies;


import java.util.Random;

import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Entities.Player;



/**
 * The Enemy_Factory generates random monsters appropriately according
 * to the player's level and location
 */
public class Enemy_Factory
{
    Random random = new Random();

    public Enemy generateEnemy(Player player) {
        int randomInt = random.nextInt(5) + 1;
        if (randomInt <= player.getLocation().getDangerRating()) {
            switch (player.getLocationType()) {
                case FOREST:
                    return getForestMonster(player.getLevel());
                case SWAMP:
                    return getSwampMonster(player.getLevel());
                case MOUNTAIN:
                    return getMountainMonster(player.getLevel());
                case CAVE:
                    return getCaveMonster(player.getLevel());
                case PLAINS:
                    return getPlainsMonster(player.getLevel());
                default: // any non-hostile location
                    return null;
            }
        } else {
            return null;
        }
    }

    private Enemy getForestMonster(int playerLevel) {
        int randomInt = random.nextInt(4);
        if (randomInt == 0)
            return new Bugbear(playerLevel);
        else if (randomInt == 1)
            return new Troll(playerLevel);
        else
            return new Goblin(playerLevel);
    }

    private Enemy getSwampMonster(int playerLevel) {
        int randomInt = random.nextInt(2);
        return (randomInt == 1) ? new Goblin(playerLevel) : new Troll(playerLevel);
    }

    private Enemy getMountainMonster(int playerLevel) {
        int randomInt = random.nextInt(4);
        if (randomInt == 0)
            return new Giant(playerLevel);
        else if (randomInt == 1)
            return new Troll(playerLevel);
        else if (randomInt == 2)
            return new Wolf(playerLevel);
        else
            return new Skeleton(playerLevel);
    }

    private Enemy getCaveMonster(int playerLevel) {
        int randomInt = random.nextInt(4);
        if (randomInt == 0)
            return new Troll(playerLevel);
        else if (randomInt == 1)
            return new Skeleton(playerLevel);
        else
            return new Goblin(playerLevel);
    }

    private Enemy getPlainsMonster(int playerLevel) {
        int randomInt = random.nextInt(2);
        return (randomInt == 1) ? new Bugbear(playerLevel) : new Goblin(playerLevel);
    }
}
