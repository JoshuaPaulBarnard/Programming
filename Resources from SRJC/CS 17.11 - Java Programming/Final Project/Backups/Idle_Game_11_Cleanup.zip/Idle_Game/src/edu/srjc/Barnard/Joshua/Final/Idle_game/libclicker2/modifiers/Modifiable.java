package edu.srjc.Barnard.Joshua.Final.Idle_game.libclicker2.modifiers;

public interface Modifiable
{
    void applyModification( Modifier modifier );
}
