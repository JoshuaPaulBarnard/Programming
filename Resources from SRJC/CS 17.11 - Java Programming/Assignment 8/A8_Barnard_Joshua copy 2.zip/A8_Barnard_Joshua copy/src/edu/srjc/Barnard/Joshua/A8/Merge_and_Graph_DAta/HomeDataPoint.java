package edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers.Electric_Reader;


public class HomeDataPoint
{
    /*
    HashMap<String, Double> gas_Map = new HashMap<>();

    public void setGas_Map( Gas_History gas_history )
    {
        for( Gas_Reader currentReading : gas_history )
        {
            gasMap.put( currentReading.getDate(), Double.parseDouble( currentReading.getGasUsage() ) );
        }
    }
    */

        /*
    HashMap<String, Double> electric_Map = new HashMap<>();

    public void setElectric_Map( Electric_History electric_history )
    {
        for( Electric_Reader currentReading : electric_history )
        {
            Electric_Map.put( currentReading.getDate(), Double.parseDouble( currentReading.getGasUsage() ) );
        }
    }
    */

            /*
    HashMap<String, Double> temperature_Map = new HashMap<>();

    public void setTemperature_Map( Temperature_History temperature_history )
    {
        for( Temperature_Reader currentReading : temperature_history )
        {
            gasMap.put( currentReading.getDate(), Double.parseDouble( currentReading.getGasUsage() ) );
        }
    }
    */

                /*
    HashMap<String, Double> dateMap = new HashMap<>();


    */
}

