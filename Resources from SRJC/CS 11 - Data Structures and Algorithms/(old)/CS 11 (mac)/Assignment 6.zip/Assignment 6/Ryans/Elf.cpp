//
//  ElfImplementaion.cpp
//  7_1
//
//  Created by Ryan  Martino on 10/29/17.
//  Copyright © 2017 Ryan  Martino. All rights reserved.
//
#include <stdio.h>
#include <iostream>
#include "Elf.h"
#include <string>

namespace cs_creature {
    Elf::Elf() : Creature()
    {
    }






    Elf::Elf(int newStrength, int newHitpoints)

    : Creature(newStrength, newHitpoints)

    {
    }






    std::string Elf::getSpecies() const
    {
        std::string species = "Elf";
        return species;
    }






    int Elf::getDamage() const
    {
        int damage;
        damage = Creature::getDamage();
        if ((rand() % 2) == 0) {
            std::cout << "Magical attack inflicts " << damage << " additional damage points!" << std::endl;
            damage *= 2;
        }
        return damage;
    }
}
