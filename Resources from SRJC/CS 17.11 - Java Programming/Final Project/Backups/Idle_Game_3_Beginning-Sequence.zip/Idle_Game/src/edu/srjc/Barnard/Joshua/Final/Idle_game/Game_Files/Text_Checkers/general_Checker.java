package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Text_Checkers;

import edu.srjc.Barnard.Joshua.Final.Idle_game.UI_Controller;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class general_Checker extends UI_Controller
{
    @FXML
    public TextArea Primary_Console;

    public String check_General( TextField text )
    {
        // Input Text, make lowercase.
        String toCheck = "";
        toCheck = text.getText();
        toCheck.toLowerCase();

        if( toCheck == "hello" )
        {
            Primary_Console.appendText( "Hey." + "\n" + "Whats Up." + "\n" );
        }

        return toCheck;
    }

}
