//
//  CyberDemonImplementation.cpp
//  7_1
//
//  Created by Ryan  Martino on 10/29/17.
//  Copyright © 2017 Ryan  Martino. All rights reserved.
//


#include <stdio.h>
#include <iostream>
#include "CyberDemon.h"
#include <string>

namespace cs_creature {
    CyberDemon::CyberDemon() : Demon()
    {
    }






    CyberDemon::CyberDemon(int newStrength, int newHitpoints)

    : Demon(newStrength, newHitpoints)
    {
    }






    std::string CyberDemon::getSpecies() const
    {
        std::string speciese = "CyberDemon";
        return speciese;
    }


}
