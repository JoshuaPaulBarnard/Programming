package edu.srjc.seank.cities;

public class City
{
    private String id;
    private String name;
    private String latitude;
    private String longitude;
    private String country;

    public City(String line) throws Exception
    {
        if (line.length() == 0 || line.charAt(0) == '#' )
        {
            throw new Exception("That's an empty line");
        }

        String[] fields = line.split("\t");

        if (fields.length != 5)
        {
            throw new Exception("That line has an invalid number of fields");
        }
        name = fields[1];
        country = fields[4];
    }

    public String getName()
    {
        return name;
    }

    public String getCountry()
    {
        return country;
    }
}
