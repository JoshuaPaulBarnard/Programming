package edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.libclicker2.modifiers;

public interface Modifiable
{
    void applyModification( Modifier modifier );
}
