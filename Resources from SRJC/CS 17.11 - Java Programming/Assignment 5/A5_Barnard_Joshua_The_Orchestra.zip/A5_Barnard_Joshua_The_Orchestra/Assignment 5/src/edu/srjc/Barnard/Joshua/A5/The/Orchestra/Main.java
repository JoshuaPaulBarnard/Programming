/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This assignment
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

import java.util.ArrayList;

public class Main
{

    public static void main( String[] args )
    {
        Violin playViolin = new Violin();
        Viola playViola = new Viola();
        Cello playCello = new Cello();
        Bass playBass = new Bass();
        Flute playFlute = new Flute();
        Piccolo playPiccolo = new Piccolo();
        Oboe playOboe = new Oboe();
        Clarinet playClarinet = new Clarinet();
        Bassoon playBassoon = new Bassoon();
        Trumpet playTrumpet = new Trumpet();
        Horn playHorn = new Horn();
        Trombone playTrombone = new Trombone();
        Tuba playTuba = new Tuba();
        Soprano playSoprano = new Soprano();
        Alto playAlto = new Alto();
        Tenor playTenor = new Tenor();
        Baritone playBaritone = new Baritone();

        ArrayList<Instrument> instrumentList = new ArrayList<>();

        instrumentList.add( playViolin );
        instrumentList.add( playViola );
        instrumentList.add( playCello );
        instrumentList.add( playBass );
        instrumentList.add( playFlute );
        instrumentList.add( playPiccolo );
        instrumentList.add( playOboe );
        instrumentList.add( playClarinet );
        instrumentList.add( playBassoon );
        instrumentList.add( playTrumpet );
        instrumentList.add( playHorn );
        instrumentList.add( playTrombone );
        instrumentList.add( playTuba );
        instrumentList.add( playSoprano );
        instrumentList.add( playAlto );
        instrumentList.add( playTenor );
        instrumentList.add( playBaritone );


        for( Instrument i : instrumentList )
        {
            System.out.println( i.Description() );
            i.play();
        }

    }
}
