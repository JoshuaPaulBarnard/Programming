package com.abreen.dungeon.exceptions;

/*
 * Thrown when a player tries to rekey a door.
 */
public class KeyAlreadySetException extends DungeonException {
    private static final long serialVersionUID = 1L;
}
