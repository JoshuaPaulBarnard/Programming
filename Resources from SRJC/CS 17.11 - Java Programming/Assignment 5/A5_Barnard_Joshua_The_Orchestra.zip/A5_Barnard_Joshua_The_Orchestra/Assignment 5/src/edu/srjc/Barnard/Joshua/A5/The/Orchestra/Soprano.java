/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Soprano class which extends the Saxophone class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Soprano extends Saxophone
{
    public Soprano()
    {
        this.setTransposition( true );
        this.setSingleReed( true );
        this.setDoubleReed( false );
        this.setClef( Clef.Treble );
        this.setKey( Key.Bflat );
    }
}
