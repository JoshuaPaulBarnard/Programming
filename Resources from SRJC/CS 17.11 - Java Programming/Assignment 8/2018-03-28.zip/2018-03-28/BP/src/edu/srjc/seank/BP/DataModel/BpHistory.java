package edu.srjc.seank.BP.DataModel;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BpHistory extends ArrayList<BpReading>
{
    public BpHistory(String filenName, String delimiter) throws FileNotFoundException
    {
        Scanner fIn = new Scanner(new File(filenName));

        int cnt = 0;
        String line = "";

        while (fIn.hasNextLine())
        {
            line = fIn.nextLine().trim();
            cnt += 1;
            if (cnt % 3 != 0)
            {
                continue;
            }
            if (line.length() == 0 || line.startsWith("#"))
            {
                continue;
            }

            try
            {
                this.add(new BpReading(line, delimiter));
            }
            catch (Exception e)
            {
                System.out.println(String.format("ERROR: %s, IGNORING THIS READING", e.getMessage()));
            }
        }
        Collections.reverse(this);
    }
}
