/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Trumpet class which extends the Brasswind class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Trumpet extends Brasswind
{
    public Trumpet()
    {
        this.setTransposition( true );
        this.setValves( 3 );
        this.setClef( Clef.Treble );
        this.setKey( Key.Bflat );
    }
}
