package eu.manabreak.libclicker.modifiers;

public interface Modifiable {
    void applyModification(Modifier modifier);
}
