/*
Joshua P. Barnard
jpb68@humboldt.edu
04/06/2018
Merge and Graph Data
CS 17.11

 */

package edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers;

import java.security.InvalidParameterException;

public class Two_Header_Reader
{
    private String Date;
    private String Units;
    private String Interval;
    private String Barometer;
    private String Pressure;
    private String Altimeter;
    private String inTemp;
    private String outTemp;
    private String inHumidity;
    private String outHumidity;
    private String windSpeed;
    private String windDir;
    private String windGust;
    private String windGustDir;
    private String rainRate;
    private String rain;
    private String dewPoint;
    private String windChill;
    private String heatIndex;
    private String ET;
    private String radiation;
    private String UV;
    private String extraTemp1;
    private String extraTemp2;
    private String extraTemp3;
    private String soilTemp1;
    private String soilTemp2;
    private String soilTemp3;
    private String soilTemp4;
    private String leafTemp1;
    private String leafTemp2;
    private String extraHumid1;
    private String extraHumid2;
    private String soilMoist1;
    private String soilMoist2;
    private String soilMoist3;
    private String soilMoist4;
    private String leafWet1;
    private String leafWet2;
    private String rxCheckPercent;
    private String txBatteryStatus;
    private String consBatteryVoltage;
    private String hail;
    private String hailRate;
    private String heatingTemp;
    private String heatingVoltage;
    private String supplyVoltage;
    private String referenceVoltage;
    private String windBatteryStatus;
    private String rainBatteryStatus;
    private String outTempBatteryStatus;
    private String inTempBatteryStatus;


    public Two_Header_Reader( String Lines, String Separator )
    {
        if ( Lines.length() == 0 )
        {
            throw new InvalidParameterException( " List Wise Deletion was used to deal with Missing Data." );
        }
        String [] Fields = Lines.split(  Separator );

        setfields( Fields );
    }

    private void setfields( String[] Fields )
    {
        Type = Fields[ 0 ];
        Date = Fields[ 1 ];
        Start_Time = Fields[ 2 ];
        End_Time = Fields[ 3 ];
        Usage = Fields[ 4];
        Units = Fields[ 5 ];
        Notes= Fields[ 6 ];
    }


    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getUnits() {
        return Units;
    }

    public void setUnits(String units) {
        Units = units;
    }

    public String getInterval() {
        return Interval;
    }

    public void setInterval(String interval) {
        Interval = interval;
    }

    public String getBarometer() {
        return Barometer;
    }

    public void setBarometer(String barometer) {
        Barometer = barometer;
    }

    public String getPressure() {
        return Pressure;
    }

    public void setPressure(String pressure) {
        Pressure = pressure;
    }

    public String getAltimeter() {
        return Altimeter;
    }

    public void setAltimeter(String altimeter) {
        Altimeter = altimeter;
    }

    public String getInTemp() {
        return inTemp;
    }

    public void setInTemp(String inTemp) {
        this.inTemp = inTemp;
    }

    public String getOutTemp() {
        return outTemp;
    }

    public void setOutTemp(String outTemp) {
        this.outTemp = outTemp;
    }

    public String getInHumidity() {
        return inHumidity;
    }

    public void setInHumidity(String inHumidity) {
        this.inHumidity = inHumidity;
    }

    public String getOutHumidity() {
        return outHumidity;
    }

    public void setOutHumidity(String outHumidity) {
        this.outHumidity = outHumidity;
    }

    public String getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(String windSpeed) {
        this.windSpeed = windSpeed;
    }

    public String getWindDir() {
        return windDir;
    }

    public void setWindDir(String windDir) {
        this.windDir = windDir;
    }

    public String getWindGust() {
        return windGust;
    }

    public void setWindGust(String windGust) {
        this.windGust = windGust;
    }

    public String getWindGustDir() {
        return windGustDir;
    }

    public void setWindGustDir(String windGustDir) {
        this.windGustDir = windGustDir;
    }

    public String getRainRate() {
        return rainRate;
    }

    public void setRainRate(String rainRate) {
        this.rainRate = rainRate;
    }

    public String getRain() {
        return rain;
    }

    public void setRain(String rain) {
        this.rain = rain;
    }

    public String getDewPoint() {
        return dewPoint;
    }

    public void setDewPoint(String dewPoint) {
        this.dewPoint = dewPoint;
    }

    public String getWindChill() {
        return windChill;
    }

    public void setWindChill(String windChill) {
        this.windChill = windChill;
    }

    public String getHeatIndex() {
        return heatIndex;
    }

    public void setHeatIndex(String heatIndex) {
        this.heatIndex = heatIndex;
    }

    public String getET() {
        return ET;
    }

    public void setET(String ET) {
        this.ET = ET;
    }

    public String getRadiation() {
        return radiation;
    }

    public void setRadiation(String radiation) {
        this.radiation = radiation;
    }

    public String getUV() {
        return UV;
    }

    public void setUV(String UV) {
        this.UV = UV;
    }

    public String getExtraTemp1() {
        return extraTemp1;
    }

    public void setExtraTemp1(String extraTemp1) {
        this.extraTemp1 = extraTemp1;
    }

    public String getExtraTemp2() {
        return extraTemp2;
    }

    public void setExtraTemp2(String extraTemp2) {
        this.extraTemp2 = extraTemp2;
    }

    public String getExtraTemp3() {
        return extraTemp3;
    }

    public void setExtraTemp3(String extraTemp3) {
        this.extraTemp3 = extraTemp3;
    }

    public String getSoilTemp1() {
        return soilTemp1;
    }

    public void setSoilTemp1(String soilTemp1) {
        this.soilTemp1 = soilTemp1;
    }

    public String getSoilTemp2() {
        return soilTemp2;
    }

    public void setSoilTemp2(String soilTemp2) {
        this.soilTemp2 = soilTemp2;
    }

    public String getSoilTemp3() {
        return soilTemp3;
    }

    public void setSoilTemp3(String soilTemp3) {
        this.soilTemp3 = soilTemp3;
    }

    public String getSoilTemp4() {
        return soilTemp4;
    }

    public void setSoilTemp4(String soilTemp4) {
        this.soilTemp4 = soilTemp4;
    }

    public String getLeafTemp1() {
        return leafTemp1;
    }

    public void setLeafTemp1(String leafTemp1) {
        this.leafTemp1 = leafTemp1;
    }

    public String getLeafTemp2() {
        return leafTemp2;
    }

    public void setLeafTemp2(String leafTemp2) {
        this.leafTemp2 = leafTemp2;
    }

    public String getExtraHumid1() {
        return extraHumid1;
    }

    public void setExtraHumid1(String extraHumid1) {
        this.extraHumid1 = extraHumid1;
    }

    public String getExtraHumid2() {
        return extraHumid2;
    }

    public void setExtraHumid2(String extraHumid2) {
        this.extraHumid2 = extraHumid2;
    }

    public String getSoilMoist1() {
        return soilMoist1;
    }

    public void setSoilMoist1(String soilMoist1) {
        this.soilMoist1 = soilMoist1;
    }

    public String getSoilMoist2() {
        return soilMoist2;
    }

    public void setSoilMoist2(String soilMoist2) {
        this.soilMoist2 = soilMoist2;
    }

    public String getSoilMoist3() {
        return soilMoist3;
    }

    public void setSoilMoist3(String soilMoist3) {
        this.soilMoist3 = soilMoist3;
    }

    public String getSoilMoist4() {
        return soilMoist4;
    }

    public void setSoilMoist4(String soilMoist4) {
        this.soilMoist4 = soilMoist4;
    }

    public String getLeafWet1() {
        return leafWet1;
    }

    public void setLeafWet1(String leafWet1) {
        this.leafWet1 = leafWet1;
    }

    public String getLeafWet2() {
        return leafWet2;
    }

    public void setLeafWet2(String leafWet2) {
        this.leafWet2 = leafWet2;
    }

    public String getRxCheckPercent() {
        return rxCheckPercent;
    }

    public void setRxCheckPercent(String rxCheckPercent) {
        this.rxCheckPercent = rxCheckPercent;
    }

    public String getTxBatteryStatus() {
        return txBatteryStatus;
    }

    public void setTxBatteryStatus(String txBatteryStatus) {
        this.txBatteryStatus = txBatteryStatus;
    }

    public String getConsBatteryVoltage() {
        return consBatteryVoltage;
    }

    public void setConsBatteryVoltage(String consBatteryVoltage) {
        this.consBatteryVoltage = consBatteryVoltage;
    }

    public String getHail() {
        return hail;
    }

    public void setHail(String hail) {
        this.hail = hail;
    }

    public String getHailRate() {
        return hailRate;
    }

    public void setHailRate(String hailRate) {
        this.hailRate = hailRate;
    }

    public String getHeatingTemp() {
        return heatingTemp;
    }

    public void setHeatingTemp(String heatingTemp) {
        this.heatingTemp = heatingTemp;
    }

    public String getHeatingVoltage() {
        return heatingVoltage;
    }

    public void setHeatingVoltage(String heatingVoltage) {
        this.heatingVoltage = heatingVoltage;
    }

    public String getSupplyVoltage() {
        return supplyVoltage;
    }

    public void setSupplyVoltage(String supplyVoltage) {
        this.supplyVoltage = supplyVoltage;
    }

    public String getReferenceVoltage() {
        return referenceVoltage;
    }

    public void setReferenceVoltage(String referenceVoltage) {
        this.referenceVoltage = referenceVoltage;
    }

    public String getWindBatteryStatus() {
        return windBatteryStatus;
    }

    public void setWindBatteryStatus(String windBatteryStatus) {
        this.windBatteryStatus = windBatteryStatus;
    }

    public String getRainBatteryStatus() {
        return rainBatteryStatus;
    }

    public void setRainBatteryStatus(String rainBatteryStatus) {
        this.rainBatteryStatus = rainBatteryStatus;
    }

    public String getOutTempBatteryStatus() {
        return outTempBatteryStatus;
    }

    public void setOutTempBatteryStatus(String outTempBatteryStatus) {
        this.outTempBatteryStatus = outTempBatteryStatus;
    }

    public String getInTempBatteryStatus() {
        return inTempBatteryStatus;
    }

    public void setInTempBatteryStatus(String inTempBatteryStatus) {
        this.inTempBatteryStatus = inTempBatteryStatus;
    }

    @Override
    public String toString()
    {
        return "electricReading{" +
                "Type ='" + Type + '\'' +
                ", Date ='" + Date + '\'' +
                ", Start_Time =" + Start_Time +
                ", End_Time =" + End_Time +
                ", Usage =" + Usage +
                ", Units =" + Units +
                ", Notes ='" + Notes + '\'' +
                '}';
    }

}