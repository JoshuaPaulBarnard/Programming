/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */


package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Navigation;



/**
 * An enumeration list of all the location types.
 * For now, it only includes environments
 * and not safe zones or city areas.
 */
public enum Location_Type
{
    FOREST,
    SWAMP,
    MOUNTAIN,
    PLAINS,
    WALL,
    ROAD,
    CAVE,
    STAIRS;
}
