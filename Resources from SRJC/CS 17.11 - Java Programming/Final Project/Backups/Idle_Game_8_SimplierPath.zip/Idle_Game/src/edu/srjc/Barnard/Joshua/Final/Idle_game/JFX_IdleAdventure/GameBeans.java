/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure;


import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Repository.Item_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Repository.Location_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Repository.NPC_Repository;

public class GameBeans
{
    public static Item_Repository getItemRepository()
    {
        return Item_Repository.createRepo();
    }

    public static Location_Repository getLocationRepository()
    {
        return Location_Repository.createRepo("");
    }

    public static Location_Repository getLocationRepository(String profile)
    {
        return Location_Repository.createRepo(profile);
    }

    public static NPC_Repository getNpcRepository()
    {
        return NPC_Repository.createRepo();
    }
}
