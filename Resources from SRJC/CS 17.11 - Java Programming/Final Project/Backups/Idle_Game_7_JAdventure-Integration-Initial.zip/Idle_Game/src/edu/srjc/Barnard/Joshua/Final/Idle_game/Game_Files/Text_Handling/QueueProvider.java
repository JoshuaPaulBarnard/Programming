package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Text_Handling;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import edu.srjc.Barnard.Joshua.Final.Idle_game.UI_Controller;

public class QueueProvider extends UI_Controller
{

    public static BlockingQueue<String> queue = new LinkedBlockingQueue<>();
    public static BlockingQueue<String> inputQueue = new LinkedBlockingQueue<>();
    public static DataOutputStream out;
    public static DataInputStream in;

    public static Socket server;


    public static void startMessenger(  )
    {

    }

    public static BlockingQueue<String> getQueue()
    {
        return queue;
    }

    public static void offer(String message)
    {

    }

    public static boolean sendToServer(String message)
    {
        return true;
    }

    public static String getInput(String message)
    {
        String input = "";
        input = pass_inputText;
        return input;
    }

    public static String take()
    {
        String message = null;
        message = pass_checkText;
        return message;
    }
}
