/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Woodwind class which extends the Winds class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public abstract class Woodwind extends Winds
{
    protected Boolean hasReed;
    protected Boolean hasDoubleReed;

    public Boolean getHasReed()
    {
        return hasReed;
    }

    public void setSingleReed( Boolean hasReed )
    {
        this.hasReed = hasReed;
    }

    public Boolean getHasDoubleReed()
    {
        return hasDoubleReed;
    }

    public void setDoubleReed( Boolean hadDoubleReed )
    {
        this.hasDoubleReed = hadDoubleReed;
    }

    @Override
    public String Description()
    {
        String info = null;
        String reeds = null;

        if ( hasDoubleReed == true )
        {
            reeds = "has Doubled Reeds.";
        }
        else if ( hasReed == true)
        {
            reeds = "has a Single Reed.";
        }
        else
        {
            reeds = "Reedless.";
        }

        if ( isTransposing == true )
        {
            info = "____________________________________________________________________________________________________\n\n"
                    + "The "
                    + this.getClass().getSimpleName()
                    + " in "
                    + this.getKey()
                    + " belongs to the "
                    + this.getClass().getSuperclass().getSimpleName()
                    + " family of instruments."
                    + "\n"
                    + "Clefs: "
                    + this.getClef()
                    + "\n"
                    + "Keys: "
                    + this.getKey()
                    + "\n"
                    + "This Instrument is Transposing, and "
                    + reeds
            ;
        }
        else
        {
            info = "____________________________________________________________________________________________________\n\n"
                    + "The "
                    + this.getClass().getSimpleName()
                    + " belongs to the "
                    + this.getClass().getSuperclass().getSimpleName()
                    + " family of instruments."
                    + "\n"
                    + "Clefs: "
                    + this.getClef()
                    + "\n"
                    + "Keys: "
                    + this.getKey()
                    + "\n"
                    + "This Instrument is not Transposing, and "
                    + reeds
            ;
        }

        return info;
    }

}
