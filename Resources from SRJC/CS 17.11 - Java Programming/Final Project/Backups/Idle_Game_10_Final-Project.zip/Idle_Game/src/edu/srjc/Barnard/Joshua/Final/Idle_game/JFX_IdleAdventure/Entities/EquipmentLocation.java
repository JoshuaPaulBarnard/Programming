/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Entities;

public enum EquipmentLocation
{
    HEAD,
    CHEST,
    LEFT_ARM,
    LEFT_HAND,
    RIGHT_ARM,
    RIGHT_HAND,
    BOTH_HANDS,
    BOTH_ARMS,
    LEGS,
    FEET
}
