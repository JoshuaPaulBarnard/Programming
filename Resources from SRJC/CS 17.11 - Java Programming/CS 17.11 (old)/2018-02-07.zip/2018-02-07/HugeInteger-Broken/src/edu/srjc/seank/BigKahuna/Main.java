package edu.srjc.seank.BigKahuna;

public class Main {

    public static void main(String[] args) {

        HugeInteger h1 = new HugeInteger("1000000000000066600000000000001");
        System.out.println(String.format("H1 has the value %s ", h1));

        h1.add(new HugeInteger("1"));
        System.out.println(String.format("H1 has the value %s ", h1));

    }
}
