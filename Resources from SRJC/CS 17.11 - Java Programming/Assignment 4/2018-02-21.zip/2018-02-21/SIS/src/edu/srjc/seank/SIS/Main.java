package edu.srjc.seank.SIS;

import edu.srjc.seank.SIS.Students.Graduate;
import edu.srjc.seank.SIS.Students.Student;
import edu.srjc.seank.SIS.Students.Undergraduate;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws AgeGreaterThan125Exception, AgeLessThanZeroException
    {

//        Person p = new Person();
//        p.setFirstName("Sean");
//
//        System.out.println(p.getFirstName());
//
//        Student s = new Student();
//        s.setFirstName("Mike");
//
//        System.out.println(s);

//        Undergraduate u = new Undergraduate();
//        u.setFirstName("Mike");
//
//        u.setMajor("Basket weaving");

        Graduate g = new Graduate();
        g.setFieldOfStudy("Physics");
        g.setFirstName("Olivia");
        try
        {
            g.setAge(134);
        }

        catch (AgeLessThanZeroException e)
        {
            System.out.println("The age was less than zero!");
        }
        catch (AgeGreaterThan125Exception e)
        {
            System.out.println("The age was bigger than 125!");
        }
        catch (Exception e)
        {

        }

        
        ArrayList<Student> stus = new ArrayList<Student>();
//        stus.add(u);
        stus.add(g);

        for (Student s : stus)
        {
            if (s instanceof Graduate)
            {
                System.out.println(
                    String.format("This is a %s whose name is %s, field of study is %s",
                        s.getClass().getSimpleName(), s.getFirstName(), ((Graduate)s).getFieldOfStudy()));
            }
            else if (s instanceof Undergraduate)
            {
                System.out.println(
                    String.format("This is a %s whose name is %s, major is %s",
                        s.getClass().getSimpleName(), s.getFirstName(), ((Undergraduate)s).getMajor()));
            }
            else
            {
                System.out.println("BORK BORK BORK");
            }

        }
    }
}
