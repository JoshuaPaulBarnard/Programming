/*
Joshua P. Barnard
jpb68@humboldt.edu
04/06/2018
Merge and Graph Data
CS 17.11

 */

package edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers;

import java.security.InvalidParameterException;

public class Zero_Header_Reader
{
    private String Type;
    private String Date;
    private Double Quantity;
    private String Units;
    private String Cost;

    public Zero_Header_Reader( String Lines, String Separator )
    {
        if ( Lines.length() == 0 )
        {
            throw new InvalidParameterException( " List Wise Deletion was used to deal with Missing Data." );
        }
        String [] Fields = Lines.split(  Separator );

        setfields( Fields );
    }

    private void setfields( String[] Fields )
    {
        Type = Fields[ 0 ];
        Date = Fields[ 1 ];
        Quantity = Double.parseDouble( Fields[ 2 ] );
        Units =  Fields[ 3 ];
        Cost = Fields[ 4];
    }



    public String getType()
    {
        return Type;
    }

    public void setType( String type )
    {
        Type = type;
    }

    public String getDate()
    {
        return Date;
    }

    public void setDate( String date )
    {
        Date = date;
    }

    public Double getQuantity()
    {
        return Quantity;
    }

    public void setQuantity( Double quantity )
    {
        Quantity = quantity;
    }

    public String getUnits()
    {
        return Units;
    }

    public void setUnits( String units )
    {
        Units = units;
    }

    public String getCost()
    {
        return Cost;
    }

    public void setCost( String cost )
    {
        Cost = cost;
    }


    @Override
    public String toString()
    {
        return "electricReading{" +
                "Type ='" + Type + '\'' +
                ", Date ='" + Date + '\'' +
                ", Quantity =" + Quantity +
                ", Units =" + Units +
                ", Cost =" + Cost +
                '}';
    }
}