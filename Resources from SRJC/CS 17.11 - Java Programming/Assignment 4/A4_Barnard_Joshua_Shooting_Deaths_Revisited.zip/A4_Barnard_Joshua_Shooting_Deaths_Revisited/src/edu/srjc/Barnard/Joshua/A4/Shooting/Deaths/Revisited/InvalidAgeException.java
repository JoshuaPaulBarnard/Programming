package edu.srjc.Barnard.Joshua.A4.Shooting.Deaths.Revisited;

public class InvalidAgeException extends Throwable
{

}
