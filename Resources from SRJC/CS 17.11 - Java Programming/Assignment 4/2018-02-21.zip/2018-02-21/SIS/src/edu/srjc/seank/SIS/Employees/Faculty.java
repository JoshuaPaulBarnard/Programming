package edu.srjc.seank.SIS.Employees;

import edu.srjc.seank.SIS.AgeGreaterThan125Exception;
import edu.srjc.seank.SIS.AgeLessThanZeroException;

public class Faculty extends Employee
{
    public Faculty()
    {
        super();
    }

    public Faculty(String firstName, String lastName, String address, String city, String state, String zip, int age) throws AgeLessThanZeroException, AgeGreaterThan125Exception
    {
        super(firstName, lastName, address, city, state, zip, age);
    }
}
