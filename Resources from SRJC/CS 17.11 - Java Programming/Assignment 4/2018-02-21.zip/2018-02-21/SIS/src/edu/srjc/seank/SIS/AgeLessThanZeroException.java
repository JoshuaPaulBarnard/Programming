package edu.srjc.seank.SIS;

public class AgeLessThanZeroException extends Throwable
{
}
