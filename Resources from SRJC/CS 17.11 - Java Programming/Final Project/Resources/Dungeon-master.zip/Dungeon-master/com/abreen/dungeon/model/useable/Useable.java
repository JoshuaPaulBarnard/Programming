package com.abreen.dungeon.model.useable;

public interface Useable {
    public void use();
}
