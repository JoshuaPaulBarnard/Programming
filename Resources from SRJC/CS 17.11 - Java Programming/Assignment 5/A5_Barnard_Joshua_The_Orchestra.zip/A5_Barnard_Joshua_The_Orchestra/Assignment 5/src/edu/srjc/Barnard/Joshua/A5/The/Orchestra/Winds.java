/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Winds class which extends the Instruments class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public abstract class Winds extends Instrument
{
    protected boolean isTransposing;

    public boolean isTransposing()
    {
        return isTransposing;
    }

    public void setTransposition( boolean newTranspose )
    {
        isTransposing = newTranspose;
    }
}
