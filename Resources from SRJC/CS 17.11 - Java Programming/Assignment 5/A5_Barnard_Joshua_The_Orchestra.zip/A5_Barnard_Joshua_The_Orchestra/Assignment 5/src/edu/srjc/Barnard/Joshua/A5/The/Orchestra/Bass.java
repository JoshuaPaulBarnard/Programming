/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Bass class which extends the Strings class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Bass extends Strings
{
        public Bass()
        {
                this.setNumberOfStrings( 4 );
                this.setClef( Clef.Bass );
                this.setClef( Clef.Tenor );
                this.setClef( Clef.Treble );
                this.setKey( Key.C );
        }

}
