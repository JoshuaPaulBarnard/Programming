/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files;



public class Death_Exception extends Exception
{
    private static final long serialVersionUID = 1L;
    private String message;

    public Death_Exception(String message)
    {
        super(message);
        this.message = message;
    }

    public String getLocalisedMessage()
    {
        return message;
    }
}
