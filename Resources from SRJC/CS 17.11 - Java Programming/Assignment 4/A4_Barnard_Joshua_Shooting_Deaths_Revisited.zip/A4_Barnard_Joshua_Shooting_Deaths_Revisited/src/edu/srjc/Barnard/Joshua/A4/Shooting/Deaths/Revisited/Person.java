package edu.srjc.Barnard.Joshua.A4.Shooting.Deaths.Revisited;

public class Person
{
    private String Name;
    private String Gender;
    private String Race;
    private String Age;

    public Person( String name, String gender, String race, String age )
    {
        Name = name;
        Gender = gender;
        Race = race;
        Age = age;
    }

    public Person()
    {

    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getRace() {
        return Race;
    }

    public void setRace(String race) {
        Race = race;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String age)
    {
        Age = age;
    }


}
