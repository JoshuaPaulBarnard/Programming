/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: Idle Game
 *
 *  Code Disclaimer:
 *  Code in this file is based off of a Text Adventure Game by JavaCoffeeBreak from 1997.
 *  http://www.javacoffeebreak.com/text-adventure/index.html
 *
 */

package edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.text_adventure;

import java.util.Vector;
import java.io.Serializable;


public class Location implements Serializable
{
    // Initialize Variables
    private String Room_Title;
    private String Room_Description;
    private Vector Room_ExitVector;

    // Initialize constructors
    public Location()
    {
        // Blank title + description
        Room_Title = new String ();
        Room_Description = new String();
        Room_ExitVector = new Vector();
    }

    // Partial constructor
    public Location( String title )
    {
        // Assign title
        Room_Title = title;

        // Blank description
        Room_Description = new String();

        // Blank exits
        Room_ExitVector = new Vector();
    }

    // Full constructor
    public Location( String title, String description )
    {
        // Assign title + description
        Room_Title = title;
        Room_Description = description;

        // Blank exits
        Room_ExitVector = new Vector();
    }

    // toString method
    public String toString()
    {
        return Room_Title;
    }

    // Adds an exit to this location
    public void addExit ( Exit exit )
    {
        Room_ExitVector.addElement (exit);
    }

    // Removes an exit from this location
    public void removeExit ( Exit exit )
    {
        if (Room_ExitVector.contains (exit))
        {
            Room_ExitVector.removeElement (exit);
        }
    }

    // Returns a vector of exits
    public Vector getExits ()
    {
        // Return a clone, as we don't want an external
        // object to modify our original vector
        return (Vector) Room_ExitVector.clone();
    }

    // Returns location title
    public String getTitle()
    {
        return Room_Title;
    }

    // Assigns location title
    public void setTitle( String roomTitle )
    {
        roomTitle = roomTitle;
    }

    // Returns location description
    public String getDescription()
    {
        return Room_Description;
    }

    // Assigns location description
    public void setDescription( String roomDescription )
    {
        roomDescription = roomDescription;
    }
}