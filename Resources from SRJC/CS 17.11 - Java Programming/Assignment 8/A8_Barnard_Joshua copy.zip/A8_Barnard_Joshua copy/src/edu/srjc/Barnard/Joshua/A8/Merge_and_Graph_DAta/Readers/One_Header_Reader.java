/*
Joshua P. Barnard
jpb68@humboldt.edu
04/06/2018
Merge and Graph Data
CS 17.11

 */

package edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers;

import java.security.InvalidParameterException;


public class One_Header_Reader
{
    private String Type;
    private String Date;
    private String Start_Time;
    private String End_Time;
    private String Usage;
    private Double Units;
    private String Notes;

    public One_Header_Reader( String Lines, String Separator )
    {
        if ( Lines.length() == 0 )
        {
            throw new InvalidParameterException( " List Wise Deletion was used to deal with Missing Data." );
        }
        String [] Fields = Lines.split(  Separator );

        setfields( Fields );
    }

    private void setfields( String[] Fields )
    {
        Type = Fields[ 0 ];
        Date = Fields[ 1 ];
        Start_Time = Fields[ 2 ];
        End_Time = Fields[ 3 ];
        Usage = Fields[ 4];
        Units = Double.parseDouble( Fields[ 5 ] );
        Notes= Fields[ 6 ];
    }



    public String getType()
    {
        return Type;
    }

    public void setType( String type )
    {
        Type = type;
    }

    public String getDate()
    {
        return Date;
    }

    public void setDate( String date )
    {
        Date = date;
    }

    public String getStart_Time()
    {
        return Start_Time;
    }

    public void setStart_Time( String start_Time )
    {
        Start_Time = start_Time;
    }

    public String getEnd_Time()
    {
        return End_Time;
    }

    public void setEnd_Time( String end_Time )
    {
        End_Time = end_Time;
    }

    public String getUsage()
    {
        return Usage;
    }

    public void setUsage( String usage )
    {
        Usage = usage;
    }

    public Double getUnits()
    {
        return Units;
    }

    public void setUnits( Double units )
    {
        Units = units;
    }

    public String getNotes()
    {
        return Notes;
    }

    public void setNotes( String notes )
    {
        Notes = notes;
    }

    @Override
    public String toString()
    {
        return "electricReading{" +
                "Type ='" + Type + '\'' +
                ", Date ='" + Date + '\'' +
                ", Start_Time =" + Start_Time +
                ", End_Time =" + End_Time +
                ", Usage =" + Usage +
                ", Units =" + Units +
                ", Notes ='" + Notes + '\'' +
                '}';
    }
}
