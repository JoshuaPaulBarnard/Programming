/*
Joshua P. Barnard
jpb68@humboldt.edu
04/06/2018
Merge and Graph Data
CS 17.11

 */

package edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;


import edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers.One_Header_Reader;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.StackPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.Cursor;
import javafx.scene.control.Label;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;


public class UI_Controller implements Initializable
{

    private HomeDataPoint electric_History;
    @FXML
    private LineChart<String, Number> MainChart;

    private CategoryAxis dateAxis = new CategoryAxis();
    private NumberAxis valueAxis = new NumberAxis();


    @Override
    public void initialize( URL url, ResourceBundle rb )
    {
        try
        {
            electric_History = new HomeDataPoint("elec.csv", "," );
        }
        catch ( FileNotFoundException e )
        {
            System.out.println( "File not found" );
        }

        dateAxis.setLabel( "Date" );
        valueAxis.setLabel( "Observations" );

        XYChart.Series Electric = new XYChart.Series();
        Electric.setName( "Electric" );

        XYChart.Series Gas = new XYChart.Series();
        Gas.setName( "Gas" );

        XYChart.Series lowTemp = new XYChart.Series();
        lowTemp.setName( "Low Temp" );

        XYChart.Series highTemp = new XYChart.Series();
        highTemp.setName( "High Temp" );


        for ( One_Header_Reader Results : electric_History)
        {
            String lblData = String.format(
                    "Type: %s\nDate: %s\nStart Time: %s\nEnd Time: %s\n%s\nUsage:%s\nUnits:%s\nNotes:",
                    Results.getType(), Results.getDate(), Results.getStart_Time(), Results.getEnd_Time(),
                    Results.getUsage(), Results.getUnits(), Results.getNotes()
            );

            XYChart.Data<Integer, Integer> dataPoint = new XYChart.Data<>( Results.getDate(), Results.getUsage() );
            Electric.getData().add( dataPoint );
            dataPoint.setNode( new DataPopup( lblData ) );
        }

        MainChart.getData().add( Electric );
        MainChart.getData().add( Gas );
        MainChart.getData().add( lowTemp );
        MainChart.getData().add( highTemp );



    }
    class DataPopup extends StackPane
    {
        public DataPopup( String content )
        {
            setPrefSize(10, 10);
            Label lblContent = createBpDataLabel(content);
            setOnMouseEntered(new EventHandler<MouseEvent>()
            {
                @Override
                public void handle( MouseEvent event )
                {
                    getChildren().setAll( lblContent );
                    setCursor( Cursor.NONE );
                    toFront();
                }
            });
            setOnMouseExited(new EventHandler<MouseEvent>()
            {
                @Override
                public void handle (MouseEvent event )
                {
                    getChildren().clear();
                }
            });
        }
        private Label createBpDataLabel( String content )
        {
            Label lbl = new Label( content );

            lbl.getStyleClass().addAll("default-color0", "chart-line-symbol", "chart-series-line" );
            lbl.setStyle( "-fx-font-size: 12px; -fx-font-weight: bold" );
            lbl.setTextFill( Color.FIREBRICK );
            lbl.setMinSize( Label.USE_PREF_SIZE, Label.USE_PREF_SIZE );
            return lbl;
        }

    }
}

