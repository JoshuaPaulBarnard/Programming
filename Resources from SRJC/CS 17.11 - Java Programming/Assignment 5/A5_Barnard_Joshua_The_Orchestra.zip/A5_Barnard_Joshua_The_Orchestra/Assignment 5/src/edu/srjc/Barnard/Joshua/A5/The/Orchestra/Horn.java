/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Horn class which extends the Brasswind class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Horn extends Brasswind
{
    public Horn()
    {
        this.setTransposition( true );
        this.setValves( 4 );
        this.setClef( Clef.Treble );
        this.setClef( Clef.Bass );
        this.setKey( Key.F );
    }
}
