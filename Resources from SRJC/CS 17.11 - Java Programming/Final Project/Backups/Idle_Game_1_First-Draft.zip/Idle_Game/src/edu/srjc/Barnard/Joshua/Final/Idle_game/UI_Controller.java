/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: Idle Game
 *
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 *
 * @author JoshuaPaulBarnard
 */
public class UI_Controller implements Initializable
{
    @FXML
    public Text HP_Current;

    @FXML
    public Text HP_Max;

    @FXML
    public Text WP_Current;

    @FXML
    public Text WP_Max;

    @FXML
    public TextArea Status_Display;

    @FXML
    public TextArea Inventory_Display;

    @FXML
    public TextArea Equipment_Display;

    @FXML
    public TextArea Crafting_Display;

    @FXML
    public TextArea Skills_Display;

    @FXML
    public TextArea Map;

    @FXML
    public TextArea Primary_Console;

    @FXML
    public TextField Text_Input;

    @FXML
    public TextArea Events_Log;

    @FXML
    public TextArea Story_Log;

    @FXML
    public TextArea Class_Log;

    @FXML
    public TextArea Skills_Log;

    @FXML
    public TextArea Combat_Log;

    @FXML
    public TextArea Extra_Log;

    @FXML
    public void InputTextHandler( ActionEvent event )
    {
        Primary_Console.appendText( Text_Input.getText() + "\n" );
        Text_Input.clear();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        // TODO
    }    

}
