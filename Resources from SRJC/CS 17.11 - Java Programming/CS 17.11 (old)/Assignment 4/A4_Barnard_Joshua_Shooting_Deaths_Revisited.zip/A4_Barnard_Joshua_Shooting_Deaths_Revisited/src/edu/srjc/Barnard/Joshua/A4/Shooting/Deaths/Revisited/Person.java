package edu.srjc.Barnard.Joshua.A4.Shooting.Deaths.Revisited;

public class Person
{

    private String id;
    private String name;
    private String date;
    private String manner_of_death;
    private String armed;
    private String age;
    private String gender;
    private String race;
    private String city;
    private String state;
    private String signs_of_mental_illness;
    private String threat_level;
    private String flee;
    private String body_camera;

    public Person( String input ) throws Exception
    {
        String[] category = input.split(",");
        if( category.length != 14 )
        {
            throw new Exception( "Invalid Categories" );
        }

        if( input.length() == 0 || input.charAt(0) == '#' )
        {
            throw new Exception( "Empty Line" );
        }

        name = category[1];
        age = category[5];
        gender = category[6];
        race = category[7];
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }


}
