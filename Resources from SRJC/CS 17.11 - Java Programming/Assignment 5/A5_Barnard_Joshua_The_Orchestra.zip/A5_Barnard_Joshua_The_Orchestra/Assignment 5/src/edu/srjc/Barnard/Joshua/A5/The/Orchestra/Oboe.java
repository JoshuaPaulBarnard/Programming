/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Oboe class which extends the Brasswind class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Oboe extends Woodwind
{
    public Oboe()
    {
        this.setTransposition( false );
        this.setSingleReed( true );
        this.setDoubleReed( true );
        this.setClef( Clef.Treble );
        this.setKey( Key.C );
    }
}
