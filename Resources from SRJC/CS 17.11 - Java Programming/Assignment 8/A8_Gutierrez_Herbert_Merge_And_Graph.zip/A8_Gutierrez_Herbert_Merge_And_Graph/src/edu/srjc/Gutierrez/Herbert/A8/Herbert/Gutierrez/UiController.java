/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.srjc.Gutierrez.Herbert.A8.Herbert.Gutierrez;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import java.io.IOException;


import javafx.application.Platform;
import javafx.event.ActionEvent;
import edu.srjc.Gutierrez.Herbert.A8.Herbert.Gutierrez.HomeDataPoint;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.StackPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.Cursor;
import javafx.scene.control.Label;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;




/**
 *
 * @author 
 */
public class UiController implements Initializable
{

    private HomeDataPoint elecHistory;
    @FXML
    private LineChart<String, Number> MainChart;

    private CategoryAxis dateAxis = new CategoryAxis();
    private NumberAxis valueAxis = new NumberAxis();


    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        try
        {
            elecHistory = new HomeDataPoint("elec.csv", ",");
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File not found");
        }

        dateAxis.setLabel("Date");
        valueAxis.setLabel("Reading");

        XYChart.Series Electric = new XYChart.Series();
        Electric.setName("Electric");
        XYChart.Series Gas = new XYChart.Series();
        Gas.setName("Gas");
        XYChart.Series Weather = new XYChart.Series();
        Weather.setName("Weather");

        for (electricReading Results : elecHistory)
        {
            String lblData = String.format("Type: %s\nDatet: %s\nStart Time: %s\nEnd time: %s\n%s\nUsage:%s\nUnits:%s\nNotes:",
                    Results.getType(), Results.getDate(), Results.getStartTime(), Results.getEndTime(), Results.getUsage(),
                    Results.getUnits(), Results.getNotes());

            XYChart.Data<String, Integer> dataPoint = new XYChart.Data<>(Results.getDate(), Results.getUsage());
            Electric.getData().add(dataPoint);
            dataPoint.setNode(new DataPopup(lblData));

            /*dataPoint = new XYChart.Data<>(Results.getDate(), Results.getStartTime());
            dataPoint.setNode(new DataPopup(lblData));
            diastolicSeries.getData().add(dataPoint);

            dataPoint = new XYChart.Data<>(Results.getDate(), Results.getEndTime());
            dataPoint.setNode(new DataPopup(lblData));
            pulseSeries.getData().add(dataPoint);*/
        }

        MainChart.getData().add(Electric);
        MainChart.getData().add(Gas);
        MainChart.getData().add(Weather);



    }
    class DataPopup extends StackPane
    {
        public DataPopup(String content)
        {
            setPrefSize(10, 10);
            Label lblContent = createBpDataLabel(content);
            setOnMouseEntered(new EventHandler<MouseEvent>()
            {
                @Override
                public void handle(MouseEvent event)
                {
                    getChildren().setAll(lblContent);
                    setCursor(Cursor.NONE);
                    toFront();
                }
            });
            setOnMouseExited(new EventHandler<MouseEvent>()
            {
                @Override
                public void handle(MouseEvent event)
                {
                    getChildren().clear();
                }
            });
        }
        private Label createBpDataLabel(String content)
        {
            Label lbl = new Label(content);

            lbl.getStyleClass().addAll("default-color0", "chart-line-symbol", "chart-series-line");
            lbl.setStyle("-fx-font-size: 12px; -fx-font-weight: bold");
            lbl.setTextFill(Color.FIREBRICK);
            lbl.setMinSize(Label.USE_PREF_SIZE, Label.USE_PREF_SIZE);
            return lbl;
        }

    }
}

