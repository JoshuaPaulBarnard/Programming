package com.abreen.dungeon.state;

public enum DayPart {
    DAY, NIGHT
}