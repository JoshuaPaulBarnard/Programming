/**
 * This package provides utility classes for finding type information for generic types.
 *
 * @author Inderjeet Singh, Joel Leitch
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.reflect;