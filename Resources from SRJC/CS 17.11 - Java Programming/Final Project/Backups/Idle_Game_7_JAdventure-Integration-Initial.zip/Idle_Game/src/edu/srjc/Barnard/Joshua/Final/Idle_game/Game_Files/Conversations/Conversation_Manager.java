/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Conversations;


import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.Gson;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonParser;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonObject;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonElement;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonArray;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.GameBeans;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Entities.NPC;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Entities.Player;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Items.Item;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Death_Exception;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Trading;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Repository.NPC_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Repository.Item_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Text_Handling.QueueProvider;



public class Conversation_Manager {
    private static NPC_Repository npcRepository = NPC_Repository.createRepo();
    private static Conversation_Manager instance = null;
    private Map<NPC, List<Line>> lines = new HashMap<NPC, List<Line>>();
    private static final Map<String, Action_Type> ACTION_TYPE_MAP = new HashMap<>();
    private static final Map<String, Condition_Type> CONDITION_TYPE_MAP = new HashMap<>();

    static {
        ACTION_TYPE_MAP.put("none", Action_Type.NONE);
        ACTION_TYPE_MAP.put("attack", Action_Type.ATTACK);
        ACTION_TYPE_MAP.put("buy", Action_Type.BUY);
        ACTION_TYPE_MAP.put("sell", Action_Type.SELL);
        ACTION_TYPE_MAP.put("trade", Action_Type.TRADE);
        ACTION_TYPE_MAP.put("give", Action_Type.GIVE);
        ACTION_TYPE_MAP.put("take", Action_Type.TAKE);
        CONDITION_TYPE_MAP.put("none", Condition_Type.NONE);
        CONDITION_TYPE_MAP.put("ally", Condition_Type.ALLY);
        CONDITION_TYPE_MAP.put("enemy", Condition_Type.ENEMY);
        CONDITION_TYPE_MAP.put("level", Condition_Type.LEVEL);
        CONDITION_TYPE_MAP.put("item", Condition_Type.ITEM);
        CONDITION_TYPE_MAP.put("char type", Condition_Type.CHAR_TYPE);
    }

    public Conversation_Manager() {
        load();
    }

    public static Conversation_Manager getInstance() {
        if (instance == null) {
            instance = new Conversation_Manager();
        }
        return instance;
    }

    private void load() {
        String fileName = "json/npcs.json";
        JsonParser parser = new JsonParser();
        File f = new File(fileName);
        try {
            Reader reader = new FileReader(fileName);
            JsonObject json = parser.parse(reader).getAsJsonObject();
            json = json.get("npcs").getAsJsonObject();
            Set<Map.Entry<String, JsonElement>> entries = json.entrySet();
            for (Map.Entry<String, JsonElement> entry : entries) {
                NPC npc = npcRepository.getNpc(entry.getKey());
                JsonObject details = entry.getValue().getAsJsonObject();
                if (details.get("conversations") != null) {
                    JsonArray conversation = details.get("conversations").getAsJsonArray();
                    addConversation(npc, conversation);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void addConversation(NPC npc, JsonArray conversation) {
        List<Line> start = new ArrayList<>();
        int i = 0;
        for (JsonElement entry : conversation) {
            JsonObject details = entry.getAsJsonObject();
            start.add(getLine(i++, conversation));
        }
        lines.put(npc, start);
    }

    private Line getLine(int index, JsonArray conversation) {
        JsonObject line = conversation.get(index).getAsJsonObject();
        List<Integer> responses = new ArrayList<>();
        if (line.get("response") != null) {
            for (JsonElement i : line.get("response").getAsJsonArray()) {
                responses.add(i.getAsInt());
            }
        }
        String playerPrompt = line.get("player").getAsString();
        String text = line.get("text").getAsString();
        String[] con = line.get("condition").getAsString().split("=");
        Condition_Type condition = CONDITION_TYPE_MAP.get(con[0]);
        String conditionParameter = (con.length == 1) ? "" : con[1];
        Action_Type action = ACTION_TYPE_MAP.get(line.get("action").getAsString());
        return new Line(index, playerPrompt, text, condition, conditionParameter, responses, action);
    }

    public void startConversation(NPC npc, Player player) throws Death_Exception {
        List<Line> conversation = null;
        //Workaround as <code>lines.get(npc)</code> is not working.
        Iterator it = lines.entrySet().iterator();
        while (it.hasNext()) {
            @SuppressWarnings("unchecked")
            Map.Entry<NPC, List<Line>> entry = (Map.Entry<NPC, List<Line>>) it.next();
            if (entry.getKey().equals(npc)) {
                conversation = entry.getValue();
            }
            it.remove();
        }
        if (conversation != null) {
            Line start = null;
            for (Line l : conversation) {
                if ("".equals(l.getPlayerPrompt()) &&
                        Conversation_Manager.matchesConditions(npc, player, l)) {
                    start = l;
                    break;
                }
            }
            /*
            if (start != null) {
                QueueProvider.offer(start.getText());
                Line response = start.display(npc, player, conversation);
                triggerAction(start, npc, player);
                while (response != null) {
                    QueueProvider.offer(response.getText());
                    triggerAction(response, npc, player);
                    Line temp_response = response.display(npc, player, conversation);
                    response = temp_response;
                }
            }
            */
        }
    }

    private void triggerAction(Line line, NPC npc, Player player) throws Death_Exception {
        switch (line.getAction()) {
            case ATTACK:
                QueueProvider.offer("\n" + npc.getName() + " is now attacking you!\n");
                player.attack(npc.getName());
                break;
            case TRADE:
                Trading t = new Trading(npc, player);
                //t.trade(true, true);
                break;
        }
    }

    public static boolean matchesConditions(NPC npc, Player player, Line line) {
        switch(line.getCondition()) {
            case ALLY:
                return npc.getAllies().contains(player.getCurrentCharacterType());
            case ENEMY:
                return npc.getEnemies().contains(player.getCurrentCharacterType());
            case LEVEL:
                int requiredLevel = Integer.parseInt(line.getConditionParameter());
                return player.getLevel() >= requiredLevel;
            case ITEM:
                Item_Repository itemRepo = GameBeans.getItemRepository();
                Item requiredItem = itemRepo.getItem(line.getConditionParameter());
                return player.hasItem(requiredItem);
            case CHAR_TYPE:
                String charType = line.getConditionParameter();
                return charType.equals(player.getCurrentCharacterType());
            default: // No condition
                return true;
        }
    }
}
