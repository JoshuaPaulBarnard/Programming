#include <stdio.h>
#include "mystring.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cassert>
#include <cstring>
namespace cs_mystring {






    MyString::MyString()
    {
        len = 0;
        String = new char[1];
        strcpy(String, "");
    }






    MyString::MyString(const char *inString)
    {
        len = 0;
        String = new char[strlen(inString) + 1];
        strcpy(String, inString);
    }






    MyString::MyString(const MyString& right)
    {
        len = right.len;
        String = new char[strlen(right.String) + 1];
        strcpy(String, right.String);
    }






    MyString::~MyString()
    {
        delete [] String;
    }






    std::ostream& operator<<(std::ostream& out, const MyString& source)
    {
        out << source.String;
        return out;
    }



    /*
        Here first the String in the istream is read into a temp array, Then a new array
        is allocated guaranteed to be the exact size of the String and termChar stored in temp.
        Last the string in temp is copied into the new array and returned.
    */


    std::istream& operator>>(std::istream& in, MyString& right)
    {
        char temp[128];
        in >> temp;
        delete [] right.String;
        right.String = new char[strlen(temp) +1];
        strcpy(right.String, temp);
        return in;
    }



    /*
        Here first we skip over spaces with isspace, in.peek, and in.ignore, then make
        a temp char array and use getline to read from the stream up till the deliminating
        char "target" which is passed in as a argument. After deallocting the String array
        the string stored in temp is copied to "String"
    */


    void MyString::read(std::istream& in, char target)
    {
        while (isspace(in.peek()))
        in.ignore();
        char temp[128];
        in.getline(temp, 128, target);
        delete [] String;
        String = new char[strlen(temp) + 1];
        strcpy(String, temp);
    }






    int MyString::length()const
    {
        int len = strlen(String);
        return len;
    }






    MyString operator+(const MyString& left, const MyString& right)
    {
        MyString result;
        char *temp;
        temp = new char[strlen(left.String)];
        strcpy(temp, left.String);
        char *concatString;
        concatString = new char[strlen(temp) + strlen(right.String)];
        concatString = strcat(temp, right.String);
        result = concatString;
        return result;
    }



    MyString MyString::operator=(const MyString& right)
    {
        if (this != &right){
        len = right.len;
        delete [] String;
        String = new char[strlen(right.String) + 1];
        strcpy(String, right.String);
        }
        return *this;
    }






    MyString MyString::operator+=(const MyString& right)
    {
        *this = *this + right;
        return *this;
    }






    char MyString::operator[](int index) const
    {
        assert(index >= 0 && index < strlen(String));
        return String[index];
    }






    char& MyString::operator[](int index)
    {
        assert(index >= 0 && index < strlen(String));
        return String[index];
    }






    bool operator<(const MyString& left, const MyString& right)
    {
        bool status;
        if(strcmp(left.String, right.String) < 0){
            status = true;
        } else {
            status = false;
        }
        return status;
    }






    bool operator>(const MyString& left, const MyString& right)
    {
        bool status;
        if(strcmp(left.String, right.String) > 0){
            status = true;
        } else {
            status = false;
        }
        return status;
    }






    bool operator<=(const MyString& left, const MyString& right)
    {
        bool status;
        if(strcmp(left.String, right.String) <= 0){
            status = true;
        } else {
            status = false;
        }
        return status;
    }






    bool operator>=(const MyString& left, const MyString& right)
    {
        bool status;
        if(strcmp(left.String, right.String) >= 0){
            status = true;
        } else {
            status = false;
        }
        return status;
    }






    bool operator==(const MyString& left, const MyString& right)
    {
        bool status;
        if(strcmp(left.String, right.String) == 0){
            status = true;
        } else {
            status = false;
        }
        return status;
    }






    bool operator!=(const MyString& left, const MyString& right)
    {
        bool status;
        if(strcmp(left.String, right.String) != 0){
            status = true;
        } else {
            status = false;
        }
        return status;
    }
}
