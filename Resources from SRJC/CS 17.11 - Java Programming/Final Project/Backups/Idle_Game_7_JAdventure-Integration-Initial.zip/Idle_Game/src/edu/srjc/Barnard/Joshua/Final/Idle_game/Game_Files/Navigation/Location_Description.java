/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  All code in this file is original.
 *
 */

package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Navigation;

public class Location_Description
{

}
