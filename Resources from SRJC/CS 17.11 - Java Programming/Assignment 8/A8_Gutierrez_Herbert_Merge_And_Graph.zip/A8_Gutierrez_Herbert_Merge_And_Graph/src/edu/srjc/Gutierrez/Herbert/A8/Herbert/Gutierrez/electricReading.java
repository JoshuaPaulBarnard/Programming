package edu.srjc.Gutierrez.Herbert.A8.Herbert.Gutierrez;

import javax.xml.crypto.Data;
import java.security.InvalidParameterException;

public class electricReading
{
    private String type;
    private String Date;
    private int StartTime;
    private int EndTime;
    private int Usage;
    private int Units;
    private String Notes;

    public electricReading(String Lines, String Delimeter)
    {
        if (Lines.length()==0)
        {
            throw new InvalidParameterException(" The Line cannot have missing Values");
        }
        String [] Fields = Lines.split(  Delimeter );

        setfields(Fields);

    }

    private void setfields(String[] Fields)
    {
            type = Fields[0];
            Date = Fields[1];
            StartTime = Integer.parseInt(Fields[2]);
            EndTime = Integer.parseInt(Fields[3]);
            Usage = Integer.parseInt(Fields[4]);
            Units = Integer.parseInt(Fields[5]);
            Notes= Fields[6];
    }



    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getDate()
    {
        return Date;
    }

    public void setDate(String date)
    {
        Date = date;
    }

    public int getStartTime()
    {
        return StartTime;
    }

    public void setStartTime(int startTime)
    {
        StartTime = startTime;
    }

    public int getEndTime()
    {
        return EndTime;
    }

    public void setEndTime(int endTime)
    {
        EndTime = endTime;
    }

    public int getUsage()
    {
        return Usage;
    }

    public void setUsage(int usage)
    {
        Usage = usage;
    }

    public int getUnits()
    {
        return Units;
    }

    public void setUnits(int units)
    {
        Units = units;
    }

    public String getNotes()
    {
        return Notes;
    }

    public void setNotes(String notes)
    {
        Notes = notes;
    }

    @Override
    public String toString()
    {
        return "electricReading{" +
                "type='" + type + '\'' +
                ", Date='" + Date + '\'' +
                ", StartTime=" + StartTime +
                ", EndTime=" + EndTime +
                ", Usage=" + Usage +
                ", Units=" + Units +
                ", Notes='" + Notes + '\'' +
                '}';
    }
}
