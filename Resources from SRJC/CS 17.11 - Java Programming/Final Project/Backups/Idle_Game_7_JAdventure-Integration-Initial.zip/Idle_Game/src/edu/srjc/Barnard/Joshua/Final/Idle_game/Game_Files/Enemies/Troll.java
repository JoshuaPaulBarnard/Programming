/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Enemies;



/*
 * A monster without low damage, but high health and armour.
 */
public class Troll extends Enemy
{
    public Troll(int playerLevel)
    {
        this.enemyType = "Troll";
        this.setHealthMax(70 + playerLevel * 11);
        this.setHealth(70 + playerLevel * 11);
        this.setArmour(playerLevel + 12);
        this.setDamage(20 + playerLevel * 3);
        this.setCritChance(0.05);
        this.setIntelligence(1);
        this.setStealth(1);
        this.setDexterity(1);
        this.setXPGain(75 + playerLevel * 3);
        this.setGold(25 + playerLevel * 10);
        addRandomItems(playerLevel, "wbrd1", "ashi1", "pmil2");
    }
}
