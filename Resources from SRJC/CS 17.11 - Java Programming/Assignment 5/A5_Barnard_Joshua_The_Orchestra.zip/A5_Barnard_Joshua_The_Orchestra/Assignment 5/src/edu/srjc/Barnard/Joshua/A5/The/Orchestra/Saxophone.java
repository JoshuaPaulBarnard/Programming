/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Saxophone class which extends the Woodwind class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Saxophone extends Woodwind
{
    @Override
    public String Description()
    {
        String info = null;
        String reeds = null;

        if ( hasDoubleReed == true )
        {
            reeds = "has Doubled Reeds.";
        }
        else if ( hasReed == true)
        {
            reeds = "has a Single Reed.";
        }
        else
        {
            reeds = "Reedless.";
        }

        if ( isTransposing == true )
        {
            info = "____________________________________________________________________________________________________\n\n"
                    + "The "
                    + this.getClass().getSimpleName()
                    + " Sax in "
                    + this.getKey()
                    + " belongs to the "
                    + this.getClass().getSuperclass().getSimpleName()
                    + " family of instruments."
                    + "\n"
                    + "Clefs: "
                    + this.getClef()
                    + "\n"
                    + "Keys: "
                    + this.getKey()
                    + "\n"
                    + "This Instrument is Transposing, and "
                    + reeds
            ;
        }
        else
        {
            info = "____________________________________________________________________\n\n"
                    + "The "
                    + this.getClass().getSimpleName()
                    + " Sax belongs to the "
                    + this.getClass().getSuperclass().getSimpleName()
                    + " family of instruments."
                    + "\n"
                    + "Clefs: "
                    + this.getClef()
                    + "\n"
                    + "Keys: "
                    + this.getKey()
                    + "\n"
                    + "This Instrument is not Transposing, and "
                    + reeds
            ;
        }

        return info;
    }
}
