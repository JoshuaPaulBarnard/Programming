package edu.srjc.seank.BP.DataModel;


import java.security.InvalidParameterException;

public class BpReading
{
    private String date;
    private int systolic;
    private int diastolic;
    private int heartRate;

    public BpReading(String values, String delimiter)
    {
        if (values.length() == 0)
        {
            throw new InvalidParameterException("values parameter cannot be empty");
        }

        String[] fields = values.split("[" + delimiter + "]");
        if (fields.length != 4)
        {
            throw new InvalidParameterException(String.format("Invalid number of fields: %s", values));
        }
        setValues(fields);
    }

    private void setValues(String[] fields)
    {
        try
        {
            date = fields[0].split(" ")[0];
        }
        catch (Exception e)
        {
            throw new InvalidParameterException("Invalid date/time value");
        }
        try
        {
            systolic = Integer.parseInt(fields[1]);
            if (systolic < 0)
            {
                throw new InvalidParameterException("Invalid systolic value");
            }
        }
        catch (Exception e)
        {
            throw new InvalidParameterException("Invalid systolic value");
        }
        try
        {
            diastolic = Integer.parseInt(fields[2]);
            if (diastolic < 0)
            {
                throw new InvalidParameterException("Invalid diastolic value");
            }
        }
        catch (Exception e)
        {
            throw new InvalidParameterException("Invalid diastolic value");
        }
        try
        {
            heartRate = Integer.parseInt(fields[3]);
            if (heartRate < 0)
            {
                throw new InvalidParameterException("Invalid heart rate value");
            }
        }
        catch (Exception e)
        {
            throw new InvalidParameterException("Invalid heart rate value");
        }
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public int getSystolic()
    {
        return systolic;
    }

    public void setSystolic(int systolic)
    {
        this.systolic = systolic;
    }

    public int getDiastolic()
    {
        return diastolic;
    }

    public void setDiastolic(int diastolic)
    {
        this.diastolic = diastolic;
    }

    public int getHeartRate()
    {
        return heartRate;
    }

    public void setHeartRate(int heartRate)
    {
        this.heartRate = heartRate;
    }

    @Override
    public String toString()
    {
        return "BpReading{" +
                "date='" + date + '\'' +
                ", systolic=" + systolic +
                ", diastolic=" + diastolic +
                ", heartRate=" + heartRate +
                '}';
    }
}
