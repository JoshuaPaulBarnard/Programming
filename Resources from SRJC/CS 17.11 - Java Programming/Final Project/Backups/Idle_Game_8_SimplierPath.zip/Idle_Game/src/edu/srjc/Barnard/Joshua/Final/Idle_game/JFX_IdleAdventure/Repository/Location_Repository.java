/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github
 *  https://github.com/Progether/JAdventure
 */


package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Repository;


import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.Gson;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.reflect.TypeToken;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonElement;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonObject;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonArray;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonParser;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonPrimitive;

import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Entities.NPC;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Items.Item;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Navigation.Current_Location;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Navigation.Location;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Navigation.Location_Type;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Navigation.Coordinate;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.GameBeans;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Text_Handling.QueueProvider;




/**
 * This class loads the locations from the locations.json file on start.
 * It also provides methods for getting the initial location and the current location.
 */
public class Location_Repository
{
    private Item_Repository itemRepo = GameBeans.getItemRepository();
    private String fileName;
    private Map<Coordinate, Current_Location> locations;
    private static Location_Repository instance;

    public Location_Repository(String profileName) {
        locations = new HashMap<Coordinate, Current_Location>();
        fileName = "json/profiles/" + profileName + "/locations.json";
        load();
    }

    public static Location_Repository createRepo(String profileName) {
        if ("".equals(profileName)) {
            return instance;
        }
        if (instance == null) {
            instance = new Location_Repository(profileName);
        } else if (!instance.getFileName().contains(profileName)) {
            instance = new Location_Repository(profileName);
        }
        return instance;
    }

    private String getFileName() {
        return fileName;
    }

    private void load() {
        JsonParser parser = new JsonParser();
        File f = new File(fileName);
        if (!f.exists()) {
            copyLocationsFile();
        }
        try {
            Reader reader = new FileReader(fileName);
            JsonObject json = parser.parse(reader).getAsJsonObject();
            for(Map.Entry<String, JsonElement> entry: json.entrySet()) {
                locations.put(new Coordinate(entry.getKey()), loadLocation(entry.getValue().getAsJsonObject()));
            }
            reader.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            System.exit(-1);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Current_Location loadLocation(JsonObject json) {
        Coordinate coordinate = new Coordinate(json.get("coordinate").getAsString());
        String title = json.get("title").getAsString();
        String description = json.get("description").getAsString();
        Location_Type locationType = Location_Type.valueOf(json.get("locationType").getAsString());
        Current_Location location = new Location(coordinate, title, description, locationType);
        location.setDangerRating(json.get("danger").getAsInt());
        if (json.has("items")) {
            List<String> items = new Gson().fromJson(json.get("items"), new TypeToken<List<String>>(){}.getType());
            for (String id : items) {
                location.addItem(itemRepo.getItem(id));
            }
        }
        if (json.has("npcs")) {
            List<String> npcs = new Gson().fromJson(json.get("npcs"), new TypeToken<List<String>>(){}.getType());
            for (String npc : npcs) {
                location.addNpc(npc);
            }
        }
        return location;
    }

    public void writeLocations() {
        try {
            JsonObject jsonObject = new JsonObject();
            for (Map.Entry<Coordinate,Current_Location> entry : locations.entrySet()) {
                Current_Location location = entry.getValue();
                JsonObject locationJsonElement = new JsonObject();
                locationJsonElement.addProperty("title", location.getTitle());
                locationJsonElement.addProperty("coordinate", location.getCoordinate().toString());
                locationJsonElement.addProperty("description", location.getDescription());
                locationJsonElement.addProperty("locationType", location.getLocationType().toString());
                locationJsonElement.addProperty("danger", String.valueOf(location.getDangerRating()));
                JsonArray itemList = new JsonArray();
                List<Item> items = location.getItems();
                if (items.size() > 0) {
                    for (Item item : items) {
                        JsonPrimitive itemJson = new JsonPrimitive(item.getId());
                        itemList.add(itemJson);
                    }
                    locationJsonElement.add("items", itemList);
                }
                JsonArray npcList = new JsonArray();
                List<NPC> npcs = location.getNpcs();
                if (npcs.size() > 0) {
                    for (NPC npc : npcs) {
                        JsonPrimitive npcJson = new JsonPrimitive(npc.getId());
                        npcList.add(npcJson);
                    }
                    locationJsonElement.add("npcs", npcList);
                }
                jsonObject.add(location.getCoordinate().toString(), locationJsonElement);
            }
            Writer writer = new FileWriter(fileName);
            Gson gson = new Gson();
            gson.toJson(jsonObject, writer);
            writer.close();
            QueueProvider.offer("The game locations were saved.");
        } catch (IOException ex) {
            QueueProvider.offer("Unable to save to file " + fileName);
        }
    }

    public Current_Location getInitialLocation() {
        String profileName = fileName.split("/")[2];
        instance = null;
        Location_Repository.createRepo(profileName);
        load();
        Coordinate coordinate = new Coordinate(0, 0, -1);
        return getLocation(coordinate);
    }

    public Current_Location getLocation(Coordinate coordinate) {
        if (coordinate == null) {
            return null;
        }
        if (!locations.containsKey(coordinate)) {
            throw new Repository_Exception("Argument 'coordinate' with value '" + coordinate.toString() + "' not found in repository");
        }
        return locations.get(coordinate);
    }

    private void copyLocationsFile() {
        File source = new File("json/original_data/locations.json");
        File dest = new File(fileName);
        dest.mkdirs();
        try {
            Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addLocation(Current_Location location) {
        locations.put(location.getCoordinate(), location);
    }
}
