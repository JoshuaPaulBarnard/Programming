/**
 * Do NOT use any class in this package as they are meant for internal use in gson.
 * These classes will very likely change incompatibly in future versions. You have been warned.
 *
 * @author Inderjeet Singh, Joel Leitch, Jesse Wilson
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.internal;