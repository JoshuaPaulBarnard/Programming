package edu.srjc.seank.SIS.Employees;

public class Staff extends Employee
{
}
