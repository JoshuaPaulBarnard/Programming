package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files;

import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.libclicker2.*;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.libclicker2.World;
import edu.srjc.Barnard.Joshua.Final.Idle_game.UI_Controller;

public class Game
{
    public void Idle_Game(  )
    {
        // Setup game container (world)
        World world = new World();

        // Advance the world by 1/60th of a seconds, or 60 times per second
        world.update(1.0 / 60.0 );

        // Creates a new currency called "Gold"
        Currency credits = new Currency.Builder( world )
                .name( "Credits" )
                .build();

        // Creates a new currency called "Gold"
        Currency electrons = new Currency.Builder( world )
                .name( "Electrons" )
                .build();

        // Creates a new currency called "Gold"
        Currency protons = new Currency.Builder( world )
                .name( "Protons" )
                .build();

        // Creates a new currency called "Gold"
        Currency neutrons = new Currency.Builder( world )
                .name( "Neutrons" )
                .build();



    }
}
