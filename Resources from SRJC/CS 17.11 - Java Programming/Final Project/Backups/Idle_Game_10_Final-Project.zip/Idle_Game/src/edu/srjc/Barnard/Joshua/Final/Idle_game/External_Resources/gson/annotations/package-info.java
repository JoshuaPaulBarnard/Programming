/**
 * This package provides annotations that can be used with {@link edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.Gson}.
 * 
 * @author Inderjeet Singh, Joel Leitch
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.annotations;