package edu.srjc.seank.Person;

import java.security.InvalidParameterException;

public class Person
{
    private String name = "";
    private String address;
    private String city;
    private String state;
    private String zip;

    private int birthYear = 0;
    private int birthMonth;
    private int birthDay;

    // CTOR

    /**
     * default constructor
     */
    public Person()
    {
    }

    public Person(String name, String address, String city, int birthYear)
    {
        this.name = name;
        this.address = address;
        this.city = city;

        validateBirthYear(birthYear);

        this.birthYear = birthYear;
        //setBirthYear(birthYear);
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getZip()
    {
        return zip;
    }

    public void setZip(String zip)
    {
        this.zip = zip;
    }

    public int getBirthYear()
    {
        return birthYear;
    }

    public void setBirthYear(int birthYear)
    {
       validateBirthYear(birthYear);

        this.birthYear = birthYear;

    }

    private void validateBirthYear(int birthYear)
    {
        if (birthYear < 1800)
        {
            throw new InvalidParameterException("Invalid Birth Year");
        }
    }

    public int getBirthMonth()
    {
        return birthMonth;
    }

    public void setBirthMonth(int birthMonth)
    {
        this.birthMonth = birthMonth;
    }

    public int getBirthDay()
    {
        return birthDay;
    }

    public void setBirthDay(int birthDay)
    {
        this.birthDay = birthDay;
    }

    @Override
    public String toString()
    {
        return "Person{" + "name='" + name + '\'' + ", address='" + address + '\'' + ", city='" + city + '\'' + ", birthYear=" + birthYear + '}';
    }
}























