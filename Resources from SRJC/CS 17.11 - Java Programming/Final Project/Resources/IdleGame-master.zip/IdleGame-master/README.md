# IdleGame
A basic zombie game made by 2 cool dudes learning how to do some cool java stuf maybe one day it will be picked up again
