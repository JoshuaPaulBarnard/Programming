package adventure;

/**
 * @author SweetuPatel
 *
 * updated By
 * @author adeelahuma
 * 
 * updated By
 * @author SweetuPatel
 */
public class Response {
  
    public String kind = "";

    public String message = "";


    public Response(String kind, String message) {
        this.kind = kind;
        this.message = message;
    }

    public Response() {
    }
}
