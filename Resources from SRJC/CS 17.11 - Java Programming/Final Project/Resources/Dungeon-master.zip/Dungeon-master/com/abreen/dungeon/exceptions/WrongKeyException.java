package com.abreen.dungeon.exceptions;

/*
 * Thrown when a player tries to lock a door using the wrong key.
 */
public class WrongKeyException extends DungeonException {
    private static final long serialVersionUID = 1L;
}
