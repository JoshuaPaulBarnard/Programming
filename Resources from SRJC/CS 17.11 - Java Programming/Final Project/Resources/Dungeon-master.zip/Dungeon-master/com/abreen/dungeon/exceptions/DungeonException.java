package com.abreen.dungeon.exceptions;

/*
 * Wrapper class for game-specific exceptions.
 */
public class DungeonException extends Exception {
    private static final long serialVersionUID = 1L;
}