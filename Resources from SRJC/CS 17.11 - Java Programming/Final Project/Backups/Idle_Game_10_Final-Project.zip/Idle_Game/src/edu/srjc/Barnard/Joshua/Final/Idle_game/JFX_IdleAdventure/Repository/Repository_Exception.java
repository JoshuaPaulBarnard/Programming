/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Repository;

public class Repository_Exception extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    public Repository_Exception(String message, Throwable cause) {
        super(message, cause);
    }

    public Repository_Exception(String message) {
        super(message);
    }
}

