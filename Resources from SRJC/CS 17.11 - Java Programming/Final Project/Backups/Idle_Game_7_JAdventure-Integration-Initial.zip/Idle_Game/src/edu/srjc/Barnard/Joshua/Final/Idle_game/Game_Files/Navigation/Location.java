/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */




package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Navigation;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.GameBeans;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Entities.NPC;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Items.Item;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Items.Storage;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Enemies.Enemy;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Repository.Item_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Repository.Location_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Repository.NPC_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Repository.Repository_Exception;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Text_Handling.QueueProvider;



/**
 * The location class mostly deals with getting and setting variables.
 * It also contains the method to print a location's details.
 */
public class Location implements Current_Location {
    // @Resource
    protected static Item_Repository itemRepo = GameBeans.getItemRepository();
    protected static NPC_Repository npcRepo = GameBeans.getNpcRepository();

    private Coordinate coordinate;
    private String title;
    private String description;
    private Location_Type locationType;
    private int dangerRating;
    private Storage storage = new Storage();
    private List<NPC> npcs = new ArrayList<>();
    private List<Enemy> monsters = new ArrayList<>();

    public Location() {

    }
    public Location(Coordinate coordinate, String title, String description, Location_Type locationType) {
        this.coordinate = coordinate;
        this.title = title;
        this.description = description;
        this.locationType = locationType;
    }

    public Coordinate getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(Coordinate coordinate) {
        this.coordinate = coordinate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Location_Type getLocationType() {
        return locationType;
    }

    public void setLocationType(Location_Type locationType) {
        this.locationType = locationType;
    }

    public int getDangerRating() {
        return dangerRating;
    }

    public void setDangerRating(int dangerRating) {
        this.dangerRating = dangerRating;
    }

    // It checks each direction for an exit and adds it to the exits hashmap if it exists.
    public Map<Direction, Current_Location> getExits() {
        Map<Direction, Current_Location> exits = new HashMap<Direction, Current_Location>();
        Current_Location borderingLocation;
        Location_Repository locationRepo = GameBeans.getLocationRepository();
        for(Direction direction: Direction.values()) {
            try {
                borderingLocation = locationRepo.getLocation(getCoordinate().getBorderingCoordinate(direction));
                if (borderingLocation.getCoordinate().getZ() == getCoordinate().getZ()) {
                    exits.put(direction, borderingLocation);
                } else if (getLocationType().equals(Location_Type.STAIRS)) {
                    exits.put(direction, borderingLocation);
                }
            }
            catch (Repository_Exception ex) {
                //Location does not exist so do nothing
            }
        }
        return exits;
    }

    public Storage getStorage() {
        return storage;
    }
    public List<Item> getItems() {
        return storage.getItems();
    }

    public void addNpcs(List<String> npcIds) {
        for (String npcId : npcIds) {
            addNpc(npcId);
        }
    }

    public void addNpc(String npcId) {
        npcs.add( npcRepo.getNpc(npcId) );
    }

    public void removeNpc(NPC npc) {
        for (int i = 0; i < npcs.size(); i++) {
            if (npcs.get(i).equals(npc)) {
                npcs.remove(i);
            }
        }
    }

    public List<NPC> getNpcs() {
        return Collections.unmodifiableList(npcs);
    }

    public void addMonster(Enemy monster) {
        if (monster != null) {
            monsters.add(monster);
        }
    }

    public void removeMonster(Enemy monster) {
        for (int i = 0; i < monsters.size(); i++) {
            if (monsters.get(i).equals(monster)) {
                monsters.remove(i);
            }
        }
    }

    public List<Enemy> getMonsters() {
        return monsters;
    }

    public Item removeItem(Item item) {
        return storage.remove(item);
    }

    public void addItem(Item item) {
        storage.add(item);
    }

    public void print() {
        QueueProvider.offer("\n" + getTitle() + ":");
        QueueProvider.offer("    " + getDescription());
        List<Item> items = getItems();
        if (!items.isEmpty()) {
            QueueProvider.offer("Items:");
            for (Item item : items) {
                QueueProvider.offer("    " + item.getName());
            }
        }
        List<NPC> npcs = getNpcs();
        if (!npcs.isEmpty()) {
            QueueProvider.offer("NPCs:");
            for (NPC npc : npcs) {
                QueueProvider.offer("   " + npc.getName());
            }
        }
        QueueProvider.offer("");
        for (Map.Entry<Direction,Current_Location> direction : getExits().entrySet()) {
            QueueProvider.offer(direction.getKey().getDescription() + ": ");
            QueueProvider.offer("    " + direction.getValue().getDescription());
        }
    }
}
