/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Strings class which extends the Instruments class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public abstract class Strings extends Instrument
{
    protected int numberOfStrings;

    public int numberOfStrings()
    {
        return numberOfStrings;
    }

    public void setNumberOfStrings ( int newString )
    {
        numberOfStrings = newString;
    }





    @Override
    public String Description()
    {
        String info = null;
        String strings = null;

        if( numberOfStrings > 1 )
        {
            strings = "This Instrument has " + numberOfStrings + " Strings.";
        }
        else if( numberOfStrings == 1 )
        {
            strings = "This Instrument has " + numberOfStrings + " String.";
        }
        if( numberOfStrings < 1 )
        {
            strings = "What kind of string instrument has no strings?!";
        }


        info = "____________________________________________________________________________________________________\n\n"
                + "The "
                + this.getClass().getSimpleName()
                + " belongs to the "
                + this.getClass().getSuperclass().getSimpleName()
                + " family of instruments."
                + "\n"
                + "Clefs: "
                + this.getClef()
                + "\n"
                + "Keys: "
                + this.getKey()
                + "\n"
                + strings
        ;

        return info;
    }
}
