/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Text_Handling;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;



/**
 * Command annotates a command method in the CommandCollection
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Command
{
    String command();
    String aliases();
    String description();
    boolean debug();
}

