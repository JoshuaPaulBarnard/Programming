/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: Idle Game
 *
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game;

import java.net.URL;
import java.util.ResourceBundle;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Player.Player;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import java.io.*;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Text_Checkers.*;

/**
 *
 * @author JoshuaPaulBarnard
 */
public class UI_Controller implements Initializable
{
    @FXML
    public Text HP_Current;

    @FXML
    public Text HP_Max;

    @FXML
    public Text WP_Current;

    @FXML
    public Text WP_Max;

    @FXML
    public TextArea Status_Display;

    @FXML
    public TextArea Inventory_Display;

    @FXML
    public TextArea Equipment_Display;

    @FXML
    public TextArea Crafting_Display;

    @FXML
    public TextArea Skills_Display;

    @FXML
    public TextArea Map;

    @FXML
    public TextArea Primary_Console;

    @FXML
    public TextField Text_Input;

    @FXML
    public TextArea Events_Log;

    @FXML
    public TextArea Story_Log;

    @FXML
    public TextArea Class_Log;

    @FXML
    public TextArea Skills_Log;

    @FXML
    public TextArea Combat_Log;

    @FXML
    public TextArea Extra_Log;


    @FXML
    public String InputTextHandler( ActionEvent event )
    {
        // Input Text, and clear console's TextField.
        String inputText = "";
        String checkText = "";
        inputText = Text_Input.getText();
        checkText = Text_Input.getText().toLowerCase();
        Text_Input.clear();

        // Display formatted text in primary console.
        Primary_Console.appendText( Player.playersName + ":  " + inputText + "\n" );

        // Check input for game commands
        if( checkText.equals( "hello") )
        {
            Primary_Console.appendText( "Stranger:  Hey there!\n");
        }
        if( checkText.contains( "hey!" ) )
        {
            Primary_Console.appendText( "Stranger:  How are you?\n" );
        }

        return inputText;
    }

    public void Beginning_Sequence(  )
    {
        Primary_Console.appendText(
                "Welcome to the Idle Game Template\n" +
                        "_____________________________________________\n"
        );

        Primary_Console.appendText( "Please Enter Your Name:\n" );

        if( Player.playersName.equals( "playersName" ) && Text_Input.getText().equals( "" ) )
        {
            Primary_Console.appendText( "Error:  Please Reenter Name" );
        }

        /*
        if( Player.playersName != "" && Text_Input.getText() != "" )
        {
            Player.playersName = Text_Input.getText();
        }
        else
        {
            Primary_Console.appendText( "Error:  Please Re-enter name" );
        }
        */

    }

    @Override
    public void initialize( URL url, ResourceBundle rb )
    {
        // TODO
        Beginning_Sequence();
    }    

}
