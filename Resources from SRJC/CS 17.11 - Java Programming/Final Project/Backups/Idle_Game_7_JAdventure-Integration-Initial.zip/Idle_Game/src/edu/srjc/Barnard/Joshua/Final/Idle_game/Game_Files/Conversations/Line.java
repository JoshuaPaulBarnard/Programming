/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Conversations;


import java.util.ArrayList;
import java.util.List;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Entities.NPC;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Entities.Player;



public class Line {
    private int id;
    private String playerPrompt;
    private String text;
    private Condition_Type condition;
    private String conditionParameter;
    private List<Integer> responses;
    private Action_Type action;

    public Line(int id, String playerPrompt, String text, Condition_Type condition,
                String conditionParameter, List<Integer> responses, Action_Type action) {
        this.id = id;
        this.playerPrompt = playerPrompt;
        this.text = text;
        this.condition = condition;
        this.conditionParameter = conditionParameter;
        this.responses = responses;
        this.action = action;
    }

    public int getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public String getPlayerPrompt() {
        return playerPrompt;
    }

    public Condition_Type getCondition() {
        return condition;
    }

    public String getConditionParameter() {
        return conditionParameter;
    }

    public Action_Type getAction() {
        return action;
    }

    /*
    public Line display(NPC npc, Player player, List<Line> lines) {
        if (responses.size() == 0) {
            return null;
        }
        List<MenuItem> responseList = new ArrayList<>();
        for (Integer responseNum : responses) {
            Line response = lines.get(responseNum);
            if (ConversationManager.matchesConditions(npc, player, response)) {
                responseList.add(new MenuItem(response.getPlayerPrompt(), null));
            }
        }
        Menus responseMenu = new Menus();
        MenuItem response = responseMenu.displayMenu(responseList);
        for (int responseNum : responses) {
            Line possibleResponse = lines.get(responseNum);
            if (possibleResponse.getPlayerPrompt().equals(response.getCommand())) {
                return possibleResponse;
            }
        }
        return null;
    }
    */
}

