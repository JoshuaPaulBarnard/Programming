package com.abreen.dungeon.model;

public class Key extends Item {
    public Key(String n, String d) {
        super(n, d, true);
    }
}
