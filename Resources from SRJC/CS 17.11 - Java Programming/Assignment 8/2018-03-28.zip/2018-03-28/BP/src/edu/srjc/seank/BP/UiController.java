/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.srjc.seank.BP;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import edu.srjc.seank.BP.DataModel.BpHistory;
import edu.srjc.seank.BP.DataModel.BpReading;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

/**
 *
 * @author 
 */
public class UiController implements Initializable
{
    
    private BpHistory history = null;

    @FXML
    private LineChart<String, Number> bpChart;

    private CategoryAxis dateAxis = new CategoryAxis();
    private NumberAxis valueAxis = new NumberAxis();

    @FXML
    private MenuItem mnuFileOpen;
    @FXML
    private MenuItem mnuFileExit;

    @FXML
    private void mnuFileOpen_Click(ActionEvent e) throws IOException
    {
        FileChooser fc = new FileChooser();
        File f = fc.showOpenDialog(null);
        if (f == null)
        {
            return;
        }
        try
        {
            history = new BpHistory(f.getCanonicalPath(), ",");
        }
        catch (FileNotFoundException ex)
        {
            System.exit(0);
        }
        dateAxis.setLabel("Date");
        valueAxis.setLabel("Reading");

        XYChart.Series systolicSeries = new XYChart.Series();
        systolicSeries.setName("Systolic");

        XYChart.Series diastolicSeries = new XYChart.Series();
        diastolicSeries.setName("Dyastolic");

        XYChart.Series pulseSeries = new XYChart.Series();
        pulseSeries.setName("Pulse");

        for(BpReading r : history)
        {
            String lblData = String.format("Date: %s\nSyst: %s\nDias: %s\nPulse: %s\n",
                r.getDate(), r.getSystolic(), r.getDiastolic(), r.getHeartRate());

            XYChart.Data<String, Integer> dataPoint = new XYChart.Data<>(r.getDate(), r.getSystolic());
            systolicSeries.getData().add(dataPoint);
            dataPoint.setNode(new DataPopup(lblData));

            dataPoint = new XYChart.Data<>(r.getDate(), r.getDiastolic());
            dataPoint.setNode(new DataPopup(lblData));
            diastolicSeries.getData().add(dataPoint);

            dataPoint = new XYChart.Data<>(r.getDate(), r.getHeartRate());
            dataPoint.setNode(new DataPopup(lblData));
            pulseSeries.getData().add(dataPoint);
        }

        bpChart.getData().add(systolicSeries);
        bpChart.getData().add(diastolicSeries);
        bpChart.getData().add(pulseSeries);

    }

    @FXML
    private void mnuFileExit_Click(ActionEvent e)
    {
        Platform.exit();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
//        try
//        {
//            history = new BpHistory("BP2017.csv", ",");
//        }
//        catch (FileNotFoundException e)
//        {
//            System.exit(0);
//        }
//        dateAxis.setLabel("Date");
//        valueAxis.setLabel("Reading");
//
//        XYChart.Series systolicSeries = new XYChart.Series();
//        systolicSeries.setName("Systolic");
//
//        XYChart.Series diastolicSeries = new XYChart.Series();
//        diastolicSeries.setName("Dyastolic");
//
//        XYChart.Series pulseSeries = new XYChart.Series();
//        pulseSeries.setName("Pulse");
//
//        for(BpReading r : history)
//        {
//            String lblData = String.format("Date: %s\nSyst: %s\nDias: %s\nPulse: %s\n",
//                r.getDate(), r.getSystolic(), r.getDiastolic(), r.getHeartRate());
//
//            XYChart.Data<String, Integer> dataPoint = new XYChart.Data<>(r.getDate(), r.getSystolic());
//            systolicSeries.getData().add(dataPoint);
//            dataPoint.setNode(new DataPopup(lblData));
//
//            dataPoint = new XYChart.Data<>(r.getDate(), r.getDiastolic());
//            dataPoint.setNode(new DataPopup(lblData));
//            diastolicSeries.getData().add(dataPoint);
//
//            dataPoint = new XYChart.Data<>(r.getDate(), r.getHeartRate());
//            dataPoint.setNode(new DataPopup(lblData));
//            pulseSeries.getData().add(dataPoint);
//        }
//
//        bpChart.getData().add(systolicSeries);
//        bpChart.getData().add(diastolicSeries);
//        bpChart.getData().add(pulseSeries);

    }

    class DataPopup extends StackPane
    {
        public DataPopup(String content)
        {
            setPrefSize(10, 10);
            Label lblContent = createBpDataLabel(content);
            setOnMouseEntered(new EventHandler<MouseEvent>()
            {
                @Override
                public void handle(MouseEvent event)
                {
                    getChildren().setAll(lblContent);
                    setCursor(Cursor.NONE);
                    toFront();
                }
            });
            setOnMouseExited(new EventHandler<MouseEvent>()
            {
                @Override
                public void handle(MouseEvent event)
                {
                    getChildren().clear();
                }
            });
        }

        private Label createBpDataLabel(String content)
        {
            Label lbl = new Label(content);

            lbl.getStyleClass().addAll("default-color0", "chart-line-symbol", "chart-series-line");
            lbl.setStyle("-fx-font-size: 12px; -fx-font-weight: bold");
            lbl.setTextFill(Color.FIREBRICK);
            lbl.setMinSize(Label.USE_PREF_SIZE, Label.USE_PREF_SIZE);
            return lbl;
        }
    }
    
}
