package edu.srjc.seank.SIS;

public class AgeGreaterThan125Exception extends Throwable
{
}
