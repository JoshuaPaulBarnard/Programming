package adventure;

public class Direction extends GameObject {

	public Direction(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
