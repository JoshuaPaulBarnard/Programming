/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Bassoon class which extends the Woodwind class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Bassoon extends Woodwind
{
    public Bassoon()
    {
        this.setTransposition( false );
        this.setSingleReed( true );
        this.setDoubleReed( true );
        this.setClef( Clef.Bass );
        this.setClef( Clef.Tenor  );
        this.setKey( Key.C );
    }
}
