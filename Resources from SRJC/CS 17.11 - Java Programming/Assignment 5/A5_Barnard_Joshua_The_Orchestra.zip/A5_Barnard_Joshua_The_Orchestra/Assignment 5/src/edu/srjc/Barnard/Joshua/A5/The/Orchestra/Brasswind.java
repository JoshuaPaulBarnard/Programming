/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Brasswind class which extends the Winds class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

import java.util.ArrayList;

public abstract class Brasswind extends Winds
{

    protected int valveCount;

    public int valveCount()
    {
        return valveCount;
    }

    public void setValves ( int newValves )
    {
        valveCount = newValves;
    }


    @Override
    public String Description()
    {
        String info = null;
        String transposed = null;
        String valves = null;

        if( valveCount > 1 )
        {
            valves = "This Instrument has " + valveCount + " Valves.";
        }
        else if( valveCount == 1 )
        {
            valves = "This Instrument has " + valveCount + " Valve.";
        }
        if( valveCount < 1 )
        {
            valves = "This Instrument has no valves";
        }

        if ( isTransposing == true )
        {
            transposed = "This Instrument is Transposing.";

            info = "____________________________________________________________________________________________________\n\n"
                    + "The "
                    + this.getClass().getSimpleName()
                    + " in "
                    + this.getKey()
                    + " belongs to the "
                    + this.getClass().getSuperclass().getSimpleName()
                    + " family of instruments."
                    + "\n"
                    + "Clef(s): "
                    + this.getClef()
                    + "\n"
                    + transposed
                    + "\n"
                    + "Key(s): "
                    + this.getKey()
                    + "\n"
                    + valves
            ;
        }
        else
        {
            transposed = "This Instrument is not Transposing";

            info = "____________________________________________________________________________________________________\n\n"
                    + "The "
                    + this.getClass().getSimpleName()
                    + " belongs to the "
                    + this.getClass().getSuperclass().getSimpleName()
                    + " family of instruments."
                    + "\n"
                    + "Clef(s): "
                    + this.getClef()
                    + "\n"
                    + transposed
                    + "\n"
                    + "Key(s): "
                    + this.getKey()
                    + "\n"
                    + valves
            ;
        }

        return info;
    }

}
