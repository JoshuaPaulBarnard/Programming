/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: Idle Game
 *
 *  The real game is in the JFX_IdleAdventure package.  Here I am working with the JAdventure online community to create a
 *  JavaFX version.  I am having tremendous difficulties converting their code as my text is inputted through JavaFX,
 *  and I dont want it to be multiplier so I have to remove the SQL/Logger.  This has proven to be more difficult than I
 *  originally expected, and to save time I have defaulted to my original plan.
 *  I have adapted a Japanese man's (RyiSnow) text-adventure game to my code, and implemented the libclicker2 library
 *  from GitHub to create a rudamentary idle text-based adventure game.
 *
 *
 *  Code Disclaimer:
 *  Lines 1 - 484:  100% My Original Code
 *  Lines 485 - End:  Based on RyiSnow's Text Adventure Game
 *  http://ryisnow.net/2017/04/30/how-to-make-a-text-adventure-game-with-gui-in-java/
 *
 *  libclicker2 - https://github.com/manabreak/libclicker2
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game;


import java.net.URL;
import java.util.ResourceBundle;

import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.Gson;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonObject;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.libclicker2.*;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.libclicker2.World;


/**
 *
 * @author JoshuaPaulBarnard
 */
public class UI_Controller implements Initializable
{
    // Basic UI Handlers
    @FXML
    public Text HP_Current;

    @FXML
    public Text HP_Max;

    @FXML
    public Text WP_Current;

    @FXML
    public Text WP_Max;

    @FXML
    public Text Credits_Current;

    @FXML
    public TextArea Status_Display;

    @FXML
    public TextArea Inventory_Display;

    @FXML
    public TextArea Equipment_Display;

    @FXML
    public TextArea Crafting_Display;

    @FXML
    public TextArea Skills_Display;

    @FXML
    public TextArea Map_Log;

    @FXML
    public TextArea Primary_Console;

    @FXML
    public TextField Text_Input;

    @FXML
    public TextArea Events_Log;

    @FXML
    public TextArea Story_Log;

    @FXML
    public TextArea Class_Log;

    @FXML
    public TextArea Skills_Log;

    @FXML
    public TextArea Combat_Log;

    @FXML
    public TextArea Extra_Log;


    // Basic game control functions
    @FXML
    private void Game_Exit(  )
    {
        Platform.exit();
        System.exit(0 );
    }

    @FXML
    private void Game_Save(  )
    {
        Gson gson = new Gson();
        JsonObject jsonObject = new JsonObject();

    }

    @FXML
    private void Game_Loud(  )
    {

    }

    @FXML
    private void Game_Copy(  )
    {

    }

    @FXML
    private void Game_Paste(  )
    {

    }

    @FXML
    private void Game_Delete(  )
    {

    }

    @FXML
    private void Game_Help(  )
    {

    }

    @FXML
    private void Game_Feedback(  )
    {

    }

    @FXML
    private void Game_About(  )
    {

    }

    private int beginning_step = 1;

    private boolean isChangeName = false;
    private boolean isChangeGender = false;
    private boolean isChangeClass = false;
    private boolean isChangeColour = false;
    private boolean isGameRunning = false;


//-------------------------------------------Begin Input Event Handler-------------------------------------------------------

    // Event handler for the user pressing enter or clicking the submitButton.
    @FXML
    public void inputTextHandler(ActionEvent event )
    {
// inputText is for passing the users text into the primary console, unmodified.
// checkText is converted to lowercase and used for checking for game commands.
        String inputText = "";
        String checkText = "";
        inputText = Text_Input.getText();
        checkText = Text_Input.getText().toLowerCase();



// Display formatted text in primary console.
        Primary_Console.appendText( playersName + ":  " + inputText + "\n" );



// Beginning Sequence
        if( isChangeName == true )
        {
            if( playersName.equals( "" ) && Text_Input.getText().equals( "" ) )
            {
                Primary_Console.appendText( "Error:  Please Re-enter Name\n" );
            }
            else
            {
                playersName = Text_Input.getText();
                isChangeName = false;
                beginning_step = 3;
            }
        }

        if( isChangeGender == true )
        {
            if( checkText.contains( "female" ) )
            {
                isMale = false;
                isChangeGender = false;
                beginning_step = 4;
            }
            else if( checkText.contains( "male" ) )
            {
                isMale = true;
                isChangeGender = false;
                beginning_step = 4;
            }
        }

        if( isChangeClass == true )
        {
            if( checkText.contains( "initiate" ) )
            {
                playersClass = "Initiate";
                Class_Log.setText( "You are an Initiate." );
                isChangeClass = false;
                beginning_step = 5;
            }
            if( checkText.contains( "military" ) || checkText.contains( "operative" ) )
            {
                playersClass = "Military Operative";
                Class_Log.setText( "You are a Military Operative." );
                isChangeClass = false;
                beginning_step = 5;
            }
            if( checkText.contains( "vagabond" ) )
            {
                playersClass = "Vagabond";
                Class_Log.setText( "You are a Vagabond." );
                isChangeClass = false;
                beginning_step = 5;
            }
        }

        if( isChangeColour == true )
        {
            if( checkText.contains( "black" ) )
            {
                playersColour = "Black";
                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "red" ) )
            {
                playersColour = "Red";
                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "orange" ) )
            {
                playersColour = "Orange";
                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "yellow" ) )
            {
                playersColour = "Yellow";
                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "green" ) )
            {
                playersColour = "Green";
                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "blue" ) )
            {
                playersColour = "Blue";
                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "purple" ) )
            {
                playersColour = "Purple";
                isChangeColour = false;
                beginning_step = 6;
            }
        }

// Clear TextField
        Text_Input.clear();

// Check if it is the beginning sequence
        beginning_Sequence();

// Pass the users input text to functions which will check for keywords
        checkText_General( checkText );
        checkText_Combat( checkText );
        checkText_Skills( checkText );
        checkText_Class( checkText );
        checkText_Special( checkText );
        checkText_TextAdventure( checkText );

    }

    //-------------------------------------------End Input Event Handler-------------------------------------------------------



    public void beginning_Sequence(  )
    {
        // Intro Sequence
        if( beginning_step == 1 )
        {
            Primary_Console.appendText(
                    "Welcome to my JavaFX Idle Text Start_Game Template!\n" +
                            "__________________________________________________\n" +
                            "\n"
            );

            beginning_step = 2;
        }

        // Name Enterance Sequence
        if( beginning_step == 2 )
        {
            isChangeName = true;

            Primary_Console.appendText(
                    "\n" +
                            "Please Enter Your Name:\n" +
                            "\n"
            );
        }

        // Gender Choice Sequence
        if( beginning_step == 3 )
        {
            isChangeGender = true;

            Primary_Console.appendText(
                    "\n" +
                            "What Gender Are you?\n" +
                            "Male\n" +
                            "Female\n" +
                            "\n"
            );
        }

        // Class Choice Sequence
        if( beginning_step == 4 )
        {
            isChangeClass = true;

            Primary_Console.appendText(
                    "\n" +
                            "What is your class?\n" +
                            "Initiate\n" +
                            "Military Operative\n" +
                            "Vagabond\n" +
                            "\n'"
            );
        }


        // Players Favorite Color Choice Sequence
        if( beginning_step == 5 )
        {
            isChangeColour = true;

            Primary_Console.appendText(
                    "\n" +
                            "What is your favorite colour?\n" +
                            "Red\n" +
                            "Yellow\n" +
                            "Orage\n" +
                            "Green\n" +
                            "Blue\n" +
                            "Purple\n" +
                            "Black\n" +
                            "\n"
            );
        }


        // Beginning Start_Game Sequence
        if( beginning_step == 6 )
        {
            Primary_Console.appendText(
                    "\n" +
                            "Thank you for your choices!\n" +
                            "Enjoy The Start_Game!!\n" +
                            "\n"
            );

            beginning_step = 0;
        }

        // Play the Start_Game
        if( beginning_step == 0 )
        {
            isGameRunning = true;
            Start_Game();

        }
    }






//---------------------------------------------------- Start Text Checkers ------------------------------------------------------------------------------

    public void checkText_General( String CheckText )
    {

        // Check input for game commands
        if( CheckText.equals( "quit" ) )
        {
            Game_Exit();
        }
        if( CheckText.equals( "save" ) )
        {
            Game_Save();
        }
        if( CheckText.equals( "load" ) )
        {
            Game_Loud();
        }

        //Check for Directions
        if( CheckText.equals( "up" ) )
        {

        }
        if( CheckText.equals( "down" ) )
        {

        }
        if( CheckText.equals( "left" ) )
        {

        }
        if( CheckText.equals( "right" ) )
        {

        }
        if( CheckText.equals( "north" ) )
        {

        }
        if( CheckText.equals( "south" ) )
        {

        }
        if( CheckText.equals( "east" ) )
        {

        }
        if( CheckText.equals( "west" ) )
        {

        }
        if( CheckText.contains( "autowanderning" ) && CheckText.contains( "on" ) )
        {

        }
        if( CheckText.contains( "autowanderning" ) && CheckText.contains( "off" ) )
        {

        }
    }

    public void checkText_Combat( String CheckText )
    {

    }

    public void checkText_Skills( String CheckText )
    {

    }

    public void checkText_Class( String CheckText )
    {

    }

    public void checkText_Special( String CheckText )
    {

    }

//----------------------------------------------------- End Text Checkers -------------------------------------------------------------------------------

//-----------------------------------------------------Start the Games Code--------------------------------------------------------------------------

    public String playersName = "";
    public boolean isMale = true;
    public String playersClass = "";
    public String playersColour = "";

    int currentHP, maxHP;
    int currentWP, maxWP;
    int credits;
    int monsterHP, silverRing;
    String weapon, position;



    public void Start_Game( )
    {
        // Setup game container (world)
        World world = new World();

        // Advance the world by 1/60th of a seconds, or 60 times per second
        world.update(1.0 / 60.0 );

        // Creates a new currency called "Credits"
        Currency credits = new Currency.Builder( world )
                .name( "Credits" )
                .build();

        Credits_Current.setText( credits.getAmountAsString() );

        playerSetup();

        Map_Log.setText(
                "\n" +
                        "    Game Map:      " + "\n" +
                        "         _       " + "\n" +
                        "        |_|      " + "\n" +
                        "         |       " + "\n" +
                        " _      _      _ " + "\n" +
                        "|_| - |_| - |_|" + "\n" +
                        "         |       " + "\n" +
                        "         _       " + "\n" +
                        "        |_|      " + "\n"
        );

    }

    public void playerSetup()
    {
        currentHP = 15;
        maxHP = 20;
        currentWP = 10;
        maxWP = 10;
        monsterHP = 20;


        String currentHP_String = Integer.toString( currentHP );
        HP_Current.setText( currentHP_String);

        String maxHP_String = Integer.toString( maxHP );
        HP_Max.setText( maxHP_String );

        String currentWP_String = Integer.toString( currentWP );
        WP_Current.setText( currentWP_String);

        String maxWP_String = Integer.toString( maxWP );
        WP_Max.setText( maxWP_String );

        Events_Log.appendText(
                "Game Controls:\n" +
                        "Choose your option by typing: 1, 2, 3, or 4\n"
        );

        Inventory_Display.appendText(
                "\n" +
                        "       Your Inventory:" +
                        "1   Knife"
        );

        townGate();
    }
    
    
    public void townGate()
    {
        position = "townGate";
        Primary_Console.appendText
        ( 
                "\n" +
                        "You are at the gate of the town.\n" +
                        "A guard is standing in front of you.\n" + "\n"+
                        "What do you do?\n" +
                        "1. Talk to the guard\n" +
                        "2. Attack the guard\n" +
                        "3. Leave\n"
         );
        Extra_Log.setText
                (
                        "\n" +
                                "You are at the gate of the town.\n" +
                                "A guard is standing in front of you.\n" + "\n"+
                                "What will you do?\n" +
                                "1. Talk to the guard\n" +
                                "2. Attack the guard\n" +
                                "3. Leave\n"
                );
    }
    
    public void talkGuard()
    {
        position = "talkGuard";
        Primary_Console.appendText(
                "\n" +
                "Guard: Hello stranger. I have never seen your face.\n" +
                "I'm sorry but we cannot let a stranger enter our town."
        );
    }
    
    public void attackGuard()
    {
        position = "attackGuard";
        Primary_Console.appendText(
                "\n" +
                        "Guard: Hey don't be stupid!\n" +"\n" +
                        "The guard fought back and hit you hard.\n" +
                        "(You receive 3 damage)"
        );
        Combat_Log.appendText(
                "\n" +
                        "You Received 3 Damage from the Guard.\n"
        );
        currentHP = currentHP -3;
        String currentHP_String = Integer.toString( currentHP );
        HP_Current.setText( currentHP_String);
    }
    
    public void crossRoad()
    {
        position = "crossRoad";
        Primary_Console.appendText(
                "\n" +
                        "You are at a crossroad.\n" + "\n" +
                        "There is a sign, it reads:\n" +
                        "If you go south, you will go back to the town.\n" + "\n" +
                        "What will you do?\n" +
                        "1.  Go north\n" +
                        "2.  Go east\n" +
                        "3.  Go south\n" +
                        "4.  Go west\n"
        );
        Extra_Log.setText(
                "\n" +
                        "You are at a crossroad.\n" + "\n" +
                        "There is a sign, it reads:\n" +
                        "If you go south, you will go back to the town.\n" + "\n" +
                        "What will you do?\n" +
                        "1.  Go north\n" +
                        "2.  Go east\n" +
                        "3.  Go south\n" +
                        "4.  Go west\n"
        );
    }
    
    public void north()
    {
        position = "north";

        Primary_Console.appendText(
                "\n" +
                        "You are at a river.\n" +
                        "You drink the water and rest at the riverside.\n" + "\n" +
                        "(Your HP is recovered by 2)\n" + "\n" +
                        "What Will you do?\n" +
                        "1.  Go south\n"
        );
        Extra_Log.setText(
                "\n" +
                        "You are at a river.\n" +
                        "You drink the water and rest at the riverside.\n" + "\n" +
                        "(Your HP is recovered by 2)\n" + "\n" +
                        "What Will you do?\n" +
                        "1.  Go south\n"
        );
        Events_Log.appendText(
                "\n" +
                        "You have recovered 2 Health Points from resting at the river.\n"
        );

        currentHP = currentHP + 2;
        String currentHP_String = Integer.toString( currentHP );
        HP_Current.setText( currentHP_String);
    }
    
    public void east()
    {
        position = "east";

        weapon = "Long Sword";

        Primary_Console.appendText(
                "\n" +
                        "You walked into a forest and found a Long Sword!\n" + "\n" +
                        "(You obtained a Long Sword)\n" + "\n" +
                        "What will you do?" + "\n" +
                        "1.  Go west\n"
        );
        Extra_Log.setText(
                "\n" +
                        "You are in a forest.\n" + "\n" +
                        "What will you do?" + "\n" +
                        "1.  Go west\n"
        );
        Events_Log.appendText(
                "\n" +
                        "You have Obtained a Long Sword.\n"
        );


    }
    
    public void west()
    {
        position = "west";

        Primary_Console.appendText(
                "\n" +
                        "You encounter a goblin!\n" + "\n" +
                        "What will you do?\n" +
                        "1.  Fight\n" +
                        "2.  Run\n"
        );

        Extra_Log.setText(
                "\n" +
                        "You encounter a goblin!\n" + "\n" +
                        "What will you do?\n" +
                        "1.  Fight\n" +
                        "2.  Run\n"
        );
    }
    
    public void fight()
    {
        position = "fight";

        Primary_Console.appendText(
                "Monter HP: " + monsterHP + "\n" + "\n" +
                "What will you do?\n" +
                "1.  Attack\n" +
                "2.  Run\n"
        );

        Combat_Log.appendText( "\n" + "Monter HP: " + monsterHP + "\n" );
    }
    
    public void playerAttack()
    {
        position = "playerAttack";

        int playerDamage = 0;

        if( weapon.equals( "Knife" ) )
        {
            playerDamage = new java.util.Random().nextInt(3);
        }
        else if( weapon.equals( "Long Sword" ) )
        {
            playerDamage = new java.util.Random().nextInt(12);
        }

        Primary_Console.appendText( "You attacked the monster and dealt " + playerDamage + " damage!" );
        Combat_Log.appendText( "You attacked the monster and dealt " + playerDamage + " damage!" );

        monsterHP = monsterHP - playerDamage;
    }

    public void monsterAttack()
    {
        position = "monsterAttack";

        int monsterDamage = 0;

        monsterDamage = new java.util.Random().nextInt(6);

        Primary_Console.appendText( "The monster attacked you and dealt " + monsterDamage + " damage!");
        Combat_Log.appendText( "The monster attacked you and dealt " + monsterDamage + " damage!");

        currentHP = currentHP - monsterDamage;
    }

    public void win()
    {
        position = "win";

        silverRing = 1;

        Primary_Console.appendText(
                "\n" +
                        "You defeated the monster!\n" +
                        "The monster dropped a ring!\n" +
                        "(You obtained a Silver Ring)\n" + "\n" +
                        "What will you do?\n" +
                        "Go east\n"
        );

        Combat_Log.appendText( "\n" + "You defeated the monster!\n" );
        Events_Log.appendText( "\n" + "You Obtained a Silver Ring.\n" );
    }

    public void lose()
    {
        position = "lose";

        Primary_Console.appendText(
                "\n" +
                        "You are dead!\n" + "\n"
        );


    }

    public void ending()
    {
        position = "ending";

        Primary_Console.appendText(
                "\n" +
                        "Guard: Oh you killed that goblin!?\n" +
                        "Thank you so much. You are true hero!\n" + "\n" +
                        "Welcome to our town!\n"
        );
    }




        public void checkText_TextAdventure( String yourChoice ) {
            switch (position) {
                case "townGate":
                    switch (yourChoice) {
                        case "1":
                            if (silverRing == 1) {
                                ending();
                            } else {
                                talkGuard();
                            }
                            break;
                        case "2":
                            attackGuard();
                            break;
                        case "3":
                            crossRoad();
                            break;
                    }
                    break;
                case "talkGuard":
                    switch (yourChoice) {
                        case "1":
                            townGate();
                            break;
                    }
                    break;
                case "attackGuard":
                    switch (yourChoice) {
                        case "1":
                            townGate();
                            break;
                    }
                    break;
                case "crossRoad":
                    switch (yourChoice) {
                        case "1":
                            north();
                            break;
                        case "2":
                            east();
                            break;
                        case "3":
                            townGate();
                            break;
                        case "4":
                            west();
                            break;
                    }
                    break;
                case "north":
                    switch (yourChoice) {
                        case "1":
                            crossRoad();
                            break;
                    }
                    break;
                case "east":
                    switch (yourChoice) {
                        case "1":
                            crossRoad();
                            break;
                    }
                    break;
                case "west":
                    switch (yourChoice) {
                        case "1":
                            fight();
                            break;
                        case "2":
                            crossRoad();
                            break;
                    }
                    break;
                case "fight":
                    switch (yourChoice) {
                        case "1":
                            playerAttack();
                            break;
                        case "2":
                            crossRoad();
                            break;
                    }
                    break;
                case "playerAttack":
                    switch (yourChoice) {
                        case "1":
                            if (monsterHP < 1) {
                                win();
                            } else {
                                monsterAttack();
                            }
                            break;
                    }
                    break;
                case "monsterAttack":
                    switch (yourChoice) {
                        case "1":
                            if (currentHP < 1) {
                                lose();
                            } else {
                                fight();
                            }
                            break;
                    }
                    break;
                case "win":
                    switch (yourChoice) {
                        case "1":
                            crossRoad();
                    }
                    break;

            }
        }



//-----------------------------------------------------End the Games Code--------------------------------------------------------------------------



    @Override
    public void initialize( URL url, ResourceBundle rb )
    {
        // TODO
        beginning_Sequence();
    }

}
