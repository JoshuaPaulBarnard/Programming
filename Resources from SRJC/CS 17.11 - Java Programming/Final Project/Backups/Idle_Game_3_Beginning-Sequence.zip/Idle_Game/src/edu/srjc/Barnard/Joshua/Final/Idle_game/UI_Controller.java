/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: Idle Game
 *
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game;

import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.libclicker2.Currency;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.libclicker2.World;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Game;
import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Player.Player;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

/**
 *
 * @author JoshuaPaulBarnard
 */
public class UI_Controller implements Initializable
{
    // Basic UI Handlers
    @FXML
    public Text HP_Current;

    @FXML
    public Text HP_Max;

    @FXML
    public Text WP_Current;

    @FXML
    public Text WP_Max;

    @FXML
    public TextArea Status_Display;

    @FXML
    public TextArea Inventory_Display;

    @FXML
    public TextArea Equipment_Display;

    @FXML
    public TextArea Crafting_Display;

    @FXML
    public TextArea Skills_Display;

    @FXML
    public TextArea Map;

    @FXML
    public TextArea Primary_Console;

    @FXML
    public TextField Text_Input;

    @FXML
    public TextArea Events_Log;

    @FXML
    public TextArea Story_Log;

    @FXML
    public TextArea Class_Log;

    @FXML
    public TextArea Skills_Log;

    @FXML
    public TextArea Combat_Log;

    @FXML
    public TextArea Extra_Log;


    // Basic game control functions
    @FXML
    private void Game_Exit(  )
    {
        Platform.exit();
        System.exit(0 );
    }

    @FXML
    private void Game_Save(  )
    {

    }

    @FXML
    private void Game_Loud(  )
    {

    }

    @FXML
    private void Game_Copy(  )
    {

    }

    @FXML
    private void Game_Paste(  )
    {

    }

    @FXML
    private void Game_Delete(  )
    {

    }

    @FXML
    private void Game_Help(  )
    {

    }

    @FXML
    private void Game_Feedback(  )
    {

    }

    @FXML
    private void Game_About(  )
    {

    }

    private int beginning_step = 1;

    private boolean changeName    = false;
    private boolean changeGender  = false;
    private boolean changeClass   = false;
    private boolean changeColour  = false;
    private boolean isGameRunning = false;



    // Event handler for the user pressing enter or clicking the submitButton.
    @FXML
    public void InputTextHandler( ActionEvent event )
    {
        // inputText is for passing the users text into the primary console, unmodified.
        // checkText is converted to lowercase and used for checking for game commands.
        String inputText = "";
        String checkText = "";
        inputText = Text_Input.getText();
        checkText = Text_Input.getText().toLowerCase();

        // Display formatted text in primary console.
        Primary_Console.appendText( Player.playersName + ":  " + inputText + "\n" );

        // Beginning Sequence
        if( changeName == true )
        {
            if( Player.playersName.equals( "" ) && Text_Input.getText().equals( "" ) )
            {
                Primary_Console.appendText( "Error:  Please Re-enter Name\n" );
            }
            else
            {
                Player.playersName = Text_Input.getText();
                changeName = false;
                beginning_step = 3;
            }
        }

        if( changeGender == true )
        {
            if( checkText.contains( "female" ) )
            {
                Player.isMale = false;
                changeGender = false;
                beginning_step = 4;
            }
            else if( checkText.contains( "male" ) )
            {
                Player.isMale = true;
                changeGender = false;
                beginning_step = 4;
            }
        }

        if( changeClass == true )
        {
            if( checkText.contains( "initiate" ) )
            {
                Player.playersClass = "Initiate";
                changeClass = false;
                beginning_step = 5;
            }
            if( checkText.contains( "military" ) || checkText.contains( "operative" ) )
            {
                Player.playersClass = "Military Operative";
                changeClass = false;
                beginning_step = 5;
            }
            if( checkText.contains( "vagabond" ) )
            {
                Player.playersClass = "Vagabond";
                changeClass = false;
                beginning_step = 5;
            }
        }

        if( changeColour == true )
        {
            if( checkText.contains( "black" ) )
            {
                Player.playersColour = "Black";
                changeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "red" ) )
            {
                Player.playersColour = "Red";
                changeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "orange" ) )
            {
                Player.playersColour = "Orange";
                changeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "yellow" ) )
            {
                Player.playersColour = "Yellow";
                changeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "green" ) )
            {
                Player.playersColour = "Green";
                changeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "blue" ) )
            {
                Player.playersColour = "Blue";
                changeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "purple" ) )
            {
                Player.playersColour = "Purple";
                changeColour = false;
                beginning_step = 6;
            }
        }

        // Clear TextField
        Text_Input.clear();


        // Check input for game commands
        if( checkText.equals( "quit" ) )
        {
            Game_Exit();
        }
        if( checkText.equals( "save" ) )
        {
            Game_Save();
        }
        if( checkText.equals( "load" ) )
        {
            Game_Loud();
        }

        //Check for Directions
        if( checkText.equals( "up" ) )
        {

        }
        if( checkText.equals( "down" ) )
        {

        }
        if( checkText.equals( "left" ) )
        {

        }
        if( checkText.equals( "right" ) )
        {

        }
        if( checkText.equals( "north" ) )
        {

        }
        if( checkText.equals( "south" ) )
        {

        }
        if( checkText.equals( "east" ) )
        {

        }
        if( checkText.equals( "west" ) )
        {

        }
        if( checkText.contains( "autowanderning" ) && checkText.contains( "on" ) )
        {

        }
        if( checkText.contains( "autowanderning" ) && checkText.contains( "off" ) )
        {

        }

        Beginning_Sequence();
    }

    public void Beginning_Sequence(  )
    {
        // Intro Sequence
        if( beginning_step == 1 )
        {
            Primary_Console.appendText(
                    "Welcome to the JavaFX Idle Game Template!\n" +
                            "__________________________________________________\n" +
                            "\n"
            );

            beginning_step = 2;
        }

        // Name Enterance Sequence
        if( beginning_step == 2 )
        {
            changeName = true;

            Primary_Console.appendText(
                    "Please Enter Your Name:\n"
            );
        }

        // Gender Choice Sequence
        if( beginning_step == 3 )
        {
            changeGender = true;

            Primary_Console.appendText(
                    "What Gender Are you?\n" +
                            "Male\n" +
                            "Female\n"
            );
        }

        // Class Choice Sequence
        if( beginning_step == 4 )
        {
            changeClass = true;

            Primary_Console.appendText(
                    "What were you, in your previous life?\n" +
                            "Initiate\n" +
                            "Military Operative\n" +
                            "Vagabond\n"
            );
        }

        // Players Favorite Color Choice Sequence
        if( beginning_step == 5 )
        {
            changeColour = true;

            Primary_Console.appendText(
                    "What is your favorite colour?\n" +
                            "Red\n" +
                            "Yellow\n" +
                            "Orage\n" +
                            "Green\n" +
                            "Blue\n" +
                            "Purple\n" +
                            "Black\n"
            );
        }

        // Beginning Game Sequence
        if( beginning_step == 6 )
        {
            Primary_Console.appendText(
                    "Thank you for your choices!\n" +
                            "Enjoy The Game!!\n" +
                            "\n"
            );

            beginning_step = 0;

            Idle_Game();
        }

        // Play the Game
        if( beginning_step == 0 )
        {
            isGameRunning = true;
            Game_Start();
        }
    }

    public void Idle_Game(  )
    {
        // Setup game container (world)
        World world = new World();

        // Advance the world by 1/60th of a seconds, or 60 times per second
        world.update(1.0 / 60.0 );

        // Creates a new currency called "Credits"
        Currency credits = new Currency.Builder( world )
                .name( "Credits" )
                .build();

        // Creates a new currency called "Electrons"
        Currency electrons = new Currency.Builder( world )
                .name( "Electrons" )
                .build();

        // Creates a new currency called "Protons"
        Currency protons = new Currency.Builder( world )
                .name( "Protons" )
                .build();

        // Creates a new currency called "Neutrons"
        Currency neutrons = new Currency.Builder( world )
                .name( "Neutrons" )
                .build();



    }

    public void Game_Start(  )
    {

    }

    @Override
    public void initialize( URL url, ResourceBundle rb )
    {
        // TODO
        Beginning_Sequence();
    }    

}
