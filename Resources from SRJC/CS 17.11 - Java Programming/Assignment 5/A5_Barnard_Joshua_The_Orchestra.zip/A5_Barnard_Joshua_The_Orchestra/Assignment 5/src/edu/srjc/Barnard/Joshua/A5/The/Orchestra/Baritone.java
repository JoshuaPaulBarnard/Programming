/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Baritone class which extends the Saxophone class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Baritone extends Saxophone
{
    public Baritone()
    {
        this.setTransposition( true );
        this.setSingleReed( true );
        this.setDoubleReed( false );
        this.setClef( Clef.Treble );
        this.setKey( Key.Eflat );
    }
}
