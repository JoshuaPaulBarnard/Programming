package us.bogusville.seank.java.spring.seventeen;

import java.util.Scanner;

import static java.lang.System.in;

public class Main {

    public static void main(String[] args) {

        System.out.println(3.6f);
        System.out.println(1.2f * 3.0f);
        System.out.println("3.6f == 1.2f * 3.0f is " + (3.6f == (1.2f * 3.0f)));

        double x = 3.6;

        System.out.println(x);

        double y = 1.2 * 3.0;

        System.out.println(y);

        System.out.println("3.6 == 1.2 * 3.0 is " + (3.6 == (1.2 * 3.0)));

        String s1 = "Hello";
        if (s1 == "Hello")
        {
            System.out.println("Yep");
        }
        else
        {
            System.out.println("Nope");
        }

        String s2 = "Hello";
        if (s1 == s2)
        {
            System.out.println("Yep");
        }
        else
        {
            System.out.println("Nope");
        }



        Scanner kbd = new Scanner(in);
        System.out.print("What is your name: ");
        String yourName = kbd.nextLine();

        if (yourName == "Fred")
        {
            System.out.println("Yep");
        }
        else
        {
            System.out.println("Nope");
        }


        if (yourName.equals("Fred"))
        {
            System.out.println("Yep");
        }
        else
        {
            System.out.println("Nope");
        }
    }
}
