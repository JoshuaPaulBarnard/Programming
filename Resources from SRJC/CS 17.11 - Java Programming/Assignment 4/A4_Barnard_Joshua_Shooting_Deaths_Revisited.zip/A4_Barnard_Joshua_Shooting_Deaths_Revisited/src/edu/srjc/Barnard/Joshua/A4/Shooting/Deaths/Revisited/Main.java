package edu.srjc.Barnard.Joshua.A4.Shooting.Deaths.Revisited;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Scanner;

import edu.srjc.Barnard.Joshua.A4.Shooting.Deaths.Revisited.WaPoDeath;

public class Main {

    public static void main(String[] args)
    {
	// write your code he

        String line = "";
        int lineNumber = 0;
        Scanner inputFile = null;
        WaPoDeath Death = null;

        try
        {
            inputFile = new Scanner( new FileReader( "WaPo-fatal-police-shootings-data.csv" ) );
        }
        catch( Exception ex )
        {
            System.err.println("File Not Found.");
            System.err.println( "Please reload the program, and try again" );
            System.exit( 0 );
        }

        ArrayList<WaPoDeath> state = new ArrayList<>();
        ArrayList<WaPoDeath> gender = new ArrayList<>();
        ArrayList<Exception> errors = new ArrayList<>();

        HashMap<String, Integer> stateCount = new HashMap<>();
        HashMap<String, Integer> genderCount = new HashMap<>();

        while( inputFile.hasNext() )
        {

            line = inputFile.nextLine().trim();
            lineNumber++;
        }
        try
        {
            Death = new WaPoDeath( line );
            state.add( Death );
            gender.add( Death );
        }
        catch( Exception ex )
        {

        }
        inputFile.close();


        for( WaPoDeath S: state )
        {
            if( stateCount.containsKey( S.getState() ) )
            {
                int stateCounter = stateCount.get( S.getState() );
                stateCount.put( S.getState(), stateCounter + 1 );
            }
            else
            {
                stateCount.put( S.getState(), 1 );
            }
        }

        System.out.println( "Deaths in each state for males:" );
        for( WaPoDeath S: gender )
        {
            if( genderCount.containsKey( S.getGender() ) )
            {
                int genderCounter = genderCount.get( S.getGender() );
                genderCount.put( S.getGender(), genderCounter + 1 );
                System.out.println(
                        String.format("%s: %s",
                                S.getState(), S.getGender() ) );
            }
            else
            {
                genderCount.put( S.getGender(), 1 );
            }
        }

        System.out.println( "Deaths in each state for females:" );

    }
}
