package com.abreen.dungeon.exceptions;

/*
 * Thrown when a player decides to quit.
 */
public class PlayerIsQuittingException extends DungeonException {
    private static final long serialVersionUID = 1L;
}
