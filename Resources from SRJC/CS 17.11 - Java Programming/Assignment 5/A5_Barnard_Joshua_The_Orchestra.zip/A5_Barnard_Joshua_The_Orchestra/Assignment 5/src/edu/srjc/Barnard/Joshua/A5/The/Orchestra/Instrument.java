/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Instruments abstract class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

import java.util.ArrayList;

public abstract class Instrument
{
    protected enum Clef
    {
        Alto, Tenor, Treble, Bass
    }

    protected enum Key
    {
        C, Csharp,
        Dflat, D, Dsharp,
        Eflat, E,
        F, Fsharp,
        Gflat, G, Gsharp,
        Aflat, A, Asharp,
        Bflat, B
    }

    private String name;

    protected ArrayList<Clef> clef = new ArrayList<>();
    protected ArrayList<Key> key = new ArrayList<>();

    //public abstract void play()
    public abstract String Description();

    public void play()
    {
        for( Key scale : key )
        {
            if( scale != Key.C )
            {
                System.out.println(
                    "A "
                    + this.getClass().getSimpleName()
                    + " sounds concert "
                    + scale
                    + " when written C is played."
                );
            }

            else
            {
                System.out.println( this.getClass().getSimpleName()
                        + " sounds concert "
                        + scale
                        + " when written C is played."
                );
            }
        }
    }




    public void setClef( Clef clef)
    {
        this.clef.add( clef );
    }

    public void setKey( Key key )
    {
        this.key.add( key );
    }

    public ArrayList<Clef> getClef()
    {
        return clef;
    }

    public void setClef(ArrayList<Clef> clef)
    {
        this.clef = clef;
    }

    public ArrayList<Key> getKey()
    {
        return key;
    }

    public void setKey(ArrayList<Key> key)
    {
        this.key = key;
    }

}
