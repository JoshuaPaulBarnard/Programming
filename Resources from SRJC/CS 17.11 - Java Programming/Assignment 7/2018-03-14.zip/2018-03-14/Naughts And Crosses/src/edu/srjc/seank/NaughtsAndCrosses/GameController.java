/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.srjc.seank.NaughtsAndCrosses;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

/**
 *
 * @author 
 */
public class GameController implements Initializable
{
    
    @FXML
    private GridPane gameGrid;

    private Image blankImage;
    private Image xImage;
    private Image oImage;

    private enum Players
    {
        X,
        O,
        None
    }

    Players[][] gameBoard = new Players[3][3];

    Players whoseTurn = Players.X;

    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        blankImage = new Image("images/blank.png");
        xImage = new Image("images/x.png");
        oImage = new Image("images/o.png");


        for (int i = 0; i < gameGrid.getColumnCount(); i++)
        {
            for (int j = 0; j < gameGrid.getRowCount(); j++)
            {
                gameBoard[i][j] = Players.None;

                ImageView img = new ImageView();
                img.setImage(blankImage);
                img.setFitWidth(200);
                img.setFitHeight(200);
                img.setPreserveRatio(true);
                img.setId(String.format("image%s%s", i, j));

//                img.setOnMouseClicked(new EventHandler<MouseEvent>()
//                {
//                    @Override
//                    public void handle(MouseEvent event)
//                    {
//                        imgview_Clicked(event);
//                    }
//                });

                img.setOnMouseClicked(event -> {
                    imgview_Clicked(event);
                });
                gameGrid.add(img, i,j);
            }
        }
        gameGrid.setGridLinesVisible(true);

    }
    private void imgview_Clicked(MouseEvent e)
    {
        ImageView img = (ImageView)e.getSource();
        int row = Integer.parseInt(img.getId().substring(5,6));
        int col = Integer.parseInt(img.getId().substring(6));

        if (gameBoard[row][col] == Players.None)
        {
            if (whoseTurn == Players.X)
            {
                img.setImage(xImage);
                whoseTurn = Players.O;
                gameBoard[row][col] = Players.X;
            }
            else
            {
                img.setImage(oImage);
                whoseTurn = Players.X;
                gameBoard[row][col] = Players.O;
            }
        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText(null);
            alert.setContentText("That is already taken");
            alert.showAndWait();
//            alert.show();
        }


    }
    
}




















