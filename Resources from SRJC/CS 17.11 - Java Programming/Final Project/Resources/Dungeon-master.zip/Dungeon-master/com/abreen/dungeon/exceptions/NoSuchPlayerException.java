package com.abreen.dungeon.exceptions;

/*
 * Thrown when a player specifies a player that is not in the room.
 */
public class NoSuchPlayerException extends DungeonException {
    private static final long serialVersionUID = 1L;
}
