import java.awt.Point;

//What can we do to avoid using arrays here, cause that defeats the purpose of points............

class Map
{
	Room [][] test = new Room[2][2];
	Point location = new Point(0,0);

	test[0][0] = new Room(false, false, location, false);

}