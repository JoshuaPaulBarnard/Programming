#!/bin/bash

ls -l


