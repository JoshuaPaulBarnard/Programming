package edu.srjc.seank.SIS.Students;

import edu.srjc.seank.SIS.AgeGreaterThan125Exception;
import edu.srjc.seank.SIS.AgeLessThanZeroException;

public class Graduate extends Student
{
    private String fieldOfStudy;

    public Graduate(String firstName, String lastName, String address, String city, String state, String zip, int age, String id) throws AgeLessThanZeroException, AgeGreaterThan125Exception
    {
        super(firstName, lastName, address, city, state, zip, age, id);
    }

    public Graduate()
    {
        super();
    }

    public String getFieldOfStudy()
    {
        return fieldOfStudy;
    }

    public void setFieldOfStudy(String fieldOfStudy)
    {
        this.fieldOfStudy = fieldOfStudy;
    }
}
