package edu.srjc.Gutierrez.Herbert.A8.Herbert.Gutierrez;

import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;





public class HomeDataPoint extends ArrayList<electricReading>
{


    public HomeDataPoint(String FileName, String Delimiter) throws FileNotFoundException
    {
        Scanner InFile = new Scanner(new File(FileName));
        int cnt = 0;
        String line = "";

        while (InFile.hasNextLine())
        {
            line = InFile.nextLine().trim();
            cnt += 1;
            if (cnt % 3 != 0)
            {
                continue;
            }
            if (line.length() == 0 || line.startsWith("#"))
            {
                continue;
            }

            try
            {
                this.add(new electricReading(line, Delimiter));
            }
            catch (Exception e)
            {
                System.out.println(String.format("ERROR: %s, IGNORING THIS READING", e.getMessage()));
            }
        }
        Collections.reverse(this);

    }

}

