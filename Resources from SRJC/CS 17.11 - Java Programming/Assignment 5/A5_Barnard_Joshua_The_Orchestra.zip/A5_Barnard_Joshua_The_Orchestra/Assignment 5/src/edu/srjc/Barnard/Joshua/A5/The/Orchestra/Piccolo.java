/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Piccolo class which extends the Woodwind class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Piccolo extends Woodwind
{
    public Piccolo()
    {
        this.setTransposition( false );
        this.setSingleReed( false );
        this.setDoubleReed( false );
        this.setClef( Clef.Treble );
        this.setKey( Key.C );
    }
}
