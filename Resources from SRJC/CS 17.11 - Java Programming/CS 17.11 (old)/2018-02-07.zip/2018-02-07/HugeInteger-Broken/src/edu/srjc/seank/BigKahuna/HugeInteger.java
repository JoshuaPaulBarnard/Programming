package edu.srjc.seank.BigKahuna;

import java.security.InvalidParameterException;

public class HugeInteger
{
    private final int MAX_DIGITS = 50;
    private int[] internalValue;

    public HugeInteger(String value)
    {
        privateParse(value);
    }

    public void parse(String value)
    {
        privateParse(value);
    }

    private void privateParse(String value)
    {
        internalValue = new int[MAX_DIGITS];
        if (value.length() == 0)
        {
            throw new InvalidParameterException("nothing specified");
        }
        if (value.length() > MAX_DIGITS)
        {
            throw new InvalidParameterException("Too long");
        }
        for (int i = 0; i < value.length() - 1; i++)
        {
            if (!Character.isDigit(value.charAt(i)))
            {
                throw new InvalidParameterException("Bad character in input");
            }
        }
        int rightSide = MAX_DIGITS - 1;
        for (int i = 0; i < value.length() - 1; i++)
        {
            internalValue[rightSide] = ((int)value.charAt(i)) - '0';
            rightSide -= 1;
        }

    }

    public String toString()
    {
        boolean nonZeroFound = false;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < MAX_DIGITS; i++)
        {
            if (!(internalValue[i] == 0) && !nonZeroFound)
            {
                nonZeroFound = true;
            }
            if (nonZeroFound)
            {
                sb.append((char)(internalValue[i] + '0'));
            }

        }
        if (sb.toString().length() == 0)

        {

            sb.append('0');
        }
        return sb.toString();
    }

    public void add(HugeInteger addend)
    {
        int carry = 0;
        for (int i = 0; i < MAX_DIGITS; i++)
        {
            int a = this.internalValue[i];
            int b = addend.internalValue[i];
            int newVal = a + b + carry;
            if (newVal >= 10)
            {
                carry += 1;
                this.internalValue[i] = newVal - 10;
            }
            else
            {
                carry = 0;
                this.internalValue[i] = newVal;
            }
        }
    }












}
