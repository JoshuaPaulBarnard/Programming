package edu.srjc.Barnard.Joshua.A4.Shooting.Deaths.Revisited;

import edu.srjc.Barnard.Joshua.A4.Shooting.Deaths.Revisited.Person;

public class WaPoDeath extends Person
{
    private String Id = "";
    //private String Name = "";
    private String Date = "";
    private String Manner_Of_Death = "";
    private String Armed = "";
    //private String Age = "";
    //private String Gender = "";
    //private String Race = "";
    private String City = "";
    private String State = "";
    private String Signs_Of_Mental_Illness = "";
    private String Threat_Level = "";
    private String Flee = "";
    private String Body_Cam = "";

    public WaPoDeath( String input ) throws Exception
    {
        String[] category = input.split( "," );
        if( category.length != 14 )
        {
            throw new Exception( "Invalid Categories" );
        }

        if( input.length() == 0 || input.charAt(0) == '#' )
        {
            throw new Exception( "Empty input" );
        }
        
        Id = category[0];
        Name = category[1];
        Date = category[2];
        Manner_Of_Death = category[3];
        Armed = category[4];
        Age = category[5];
        Gender = category[6];
        Race = category[7];
        City = category[8];
        State = category[9];
        Signs_Of_Mental_Illness = category[10];
        Threat_Level = category[11];
        Flee = category[12];
        Body_Cam = category[13];
        System.out.println( category[13] );
    }

    public WaPoDeath( String name, String gender, String race, String age )
    {
        super( name, gender, race, age );
    }

    private void ageValidator( String Age ) throws InvalidAgeException
    {
    if( Age.compareTo( "100" ) > 0 )
        {
            throw new InvalidAgeException();
        }
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getManner_Of_Death() {
        return Manner_Of_Death;
    }

    public void setManner_Of_Death(String manner_Of_Death) {
        Manner_Of_Death = manner_Of_Death;
    }

    public String getArmed() {
        return Armed;
    }

    public void setArmed(String armed) {
        Armed = armed;
    }

    /*
    @Override
    public String getAge() {
        return Age;
    }

    @Override
    public void setAge(String age) {
        Age = age;
    }
    */

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getSigns_Of_Mental_Illness() {
        return Signs_Of_Mental_Illness;
    }

    public void setSigns_Of_Mental_Illness(String signs_Of_Mental_Illness) {
        Signs_Of_Mental_Illness = signs_Of_Mental_Illness;
    }

    public String getThreat_Level() {
        return Threat_Level;
    }

    public void setThreat_Level(String threat_Level) {
        Threat_Level = threat_Level;
    }

    public String getFlee() {
        return Flee;
    }

    public void setFlee( String flee )
    {
        Flee = flee;
    }

    public String getBody_Cam()
    {
        return Body_Cam;
    }

    public void setBody_Cam( String body_Cam )
    {
        Body_Cam = body_Cam;
    }




}
