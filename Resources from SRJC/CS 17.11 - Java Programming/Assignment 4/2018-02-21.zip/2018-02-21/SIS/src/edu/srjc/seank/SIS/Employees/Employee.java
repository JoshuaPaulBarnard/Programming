package edu.srjc.seank.SIS.Employees;

import edu.srjc.seank.SIS.AgeGreaterThan125Exception;
import edu.srjc.seank.SIS.AgeLessThanZeroException;
import edu.srjc.seank.SIS.Person;

public class Employee extends Person
{
    public Employee(String firstName, String lastName, String address, String city, String state, String zip, int age) throws AgeLessThanZeroException, AgeGreaterThan125Exception
    {
        super(firstName, lastName, address, city, state, zip, age);
    }

    public Employee()
    {

    }
}
