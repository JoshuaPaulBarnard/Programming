package edu.srjc.seank.cities;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class Main
{

    public static void main(String[] args)
    {

        Scanner dataFile = null;
        try
        {
            dataFile = new Scanner(new File("world_city_list.txt"));
        }
        catch (Exception ex)
        {
            System.err.println("It appears that file doesn't exist");
            System.exit(0);

            //            return;
        }

        ArrayList<String> errors = new ArrayList<>();

        int lineNumber = 0;

        ArrayList<City> cities = new ArrayList<>();

        HashMap<String, Integer> citiesCount = new HashMap<>();

        String line = "";
        while (dataFile.hasNext())
        {
            lineNumber += 1;

            line = dataFile.nextLine().trim();

            City c = null;
            try
            {
                c = new City(line);
                cities.add(c);
            }
            catch (Exception ex)
            {
                if (ex.getMessage().equals("That's an empty line"))
                {
                    continue;
                } else
                {
                    errors.add(String.format("%s on line %d", ex.getMessage(), lineNumber));
                }
            }


            //            System.out.println(line);
        }
        dataFile.close();

        for (City currentCity : cities)
        {
            //            System.out.println(String.format("%s %s", c.getName(), c.getCountry()));
            if (citiesCount.containsKey(currentCity.getCountry()))
            {
                int cityCount = citiesCount.get(currentCity.getCountry());

                citiesCount.put(currentCity.getCountry(), cityCount + 1);

                //                citiesCount.put(c.getCountry(), citiesCount.get(c.getCountry()) + 1);
            } else
            {
                citiesCount.put(currentCity.getCountry(), 1);
            }
        }

//        unsorted
//        for (String country : citiesCount.keySet())
//        {
//            int count = citiesCount.get(country);
//
//            System.out.println(String.format("%s %d", country, count));
//        }

        TreeMap<String, Integer> sortedCountries = new TreeMap<>(citiesCount);

        for (String country : sortedCountries.keySet())
        {
            int count = sortedCountries.get(country);

            System.out.println(String.format("%s %d", country, count));
        }

        if (errors.size() > 0)
        {
            for (String e : errors)
            {
                System.err.println(e);
            }
        }
    }
}
