/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Text_Handling;


import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Death_Exception;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Entities.Player;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Repository.Item_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.GameBeans;



/**
 * CommandCollection contains the declaration of the methods mapped to game commands
 *
 * The declared command methods are accessed only by reflection.
 * To declare a new command, add an appropriate method to this class and Annotate it with
 * Command(command, aliases, description)
 */
public enum Keyword_Collection
{
    INSTANCE;

    public Player player;

    private final static Map<String, String> DIRECTION_LINKS = new HashMap<String,String>();
    static
    {
        DIRECTION_LINKS.put("n", "north");
        DIRECTION_LINKS.put("s", "south");
        DIRECTION_LINKS.put("e", "east");
        DIRECTION_LINKS.put("w", "west");
        DIRECTION_LINKS.put("u", "up");
        DIRECTION_LINKS.put("d", "down");
    }



    public static Keyword_Collection getInstance() {
        return INSTANCE;
    }

    public void initPlayer(Player player) {
        this.player = player;
    }



    // command methods here
    public void command_save() 
    {
        player.save();
    }

/*
    public void command_m() {
        List<Monster> monsterList = player.getLocation().getMonsters();
        if (monsterList.size() > 0) {
            QueueProvider.offer("Monsters around you:");
            QueueProvider.offer("----------------------------");
            for (Monster monster : monsterList) {
                QueueProvider.offer(monster.monsterType);
            }
            QueueProvider.offer("----------------------------");
        } else {
            QueueProvider.offer("There are no monsters around you'n");
        }
    }
*/
/*
    public void command_g(String arg) throws Death_Exception {
        Current_Location location = player.getLocation();

        try {
            arg = DIRECTION_LINKS.get(arg);
            Direction direction = Direction.valueOf(arg.toUpperCase());
            Map<Direction, Current_Location> exits = location.getExits();
            if (exits.containsKey(direction)) {
                Current_Location newLocation = exits.get(Direction.valueOf(arg.toUpperCase()));
                if (!newLocation.getLocationType().equals(Location_Type.WALL)) {
                    player.setLocation(newLocation);
                    if ("test".equals(player.getName())) {
                        QueueProvider.offer(player.getLocation().getCoordinate().toString());
                    }
                    player.getLocation().print();
                    Random random = new Random();
                    if (player.getLocation().getMonsters().size() == 0) {
                        MonsterFactory monsterFactory = new MonsterFactory();
                        int upperBound = random.nextInt(player.getLocation().getDangerRating() + 1);
                        for (int i = 0; i < upperBound; i++) {
                            Monster monster = monsterFactory.generateMonster(player);
                            player.getLocation().addMonster(monster);
                        }
                    }
                    if (player.getLocation().getItems().size() == 0) {
                        int chance = random.nextInt(100);
                        if (chance < 60) {
                            addItemToLocation();
                        }
                    }
                    if (random.nextDouble() < 0.5) {
                        List<Monster> monsters = player.getLocation().getMonsters();
                        if (monsters.size() > 0) {
                            int posMonster = random.nextInt(monsters.size());
                            String monster = monsters.get(posMonster).monsterType;
                            QueueProvider.offer("A " + monster + " is attacking you!");
                            player.attack(monster);
                        }
                    }
                } else {
                    QueueProvider.offer("You cannot walk through walls.");
                }
            } else {
                QueueProvider.offer("The is no exit that way.");
            }
        } catch (IllegalArgumentException ex) {
            QueueProvider.offer("That direction doesn't exist");
        } catch (NullPointerException ex) {
            QueueProvider.offer("That direction doesn't exist");
        }
    }
*/

    public void command_i(String arg) {
        player.inspectItem(arg.trim());
    }


    public void command_e(String arg) {
        player.equipItem(arg.trim());
    }


    public void command_ue(String arg) {
        player.dequipItem(arg.trim());
    }

/*
    public void command_v(String arg) {
        arg = arg.trim();
        switch (arg) {
            case "s":
            case "stats":
                player.getStats();
                break;
            case "e":
            case "equipped":
                player.printEquipment();
                break;
            case "b":
            case "backpack":
                player.printStorage();
                break;
            default:
                QueueProvider.offer("That is not a valid display");
                break;
        }
    }
*/

    public void command_p(String arg) {
        player.pickUpItem(arg.trim());
    }


    public void command_d(String arg) {
        player.dropItem(arg.trim());
    }


    public void command_a(String arg) throws Death_Exception {
        player.attack(arg.trim());
    }


    public void command_la() {
        player.getLocation().print();
    }

    // Debug methods here


    public void command_attack(String arg) {
        double damage = Double.parseDouble(arg);
        player.setDamage(damage);
    }

/*
    public void command_maxhealth(String arg) {
        int healthMax = Integer.parseInt(arg);
        if (healthMax > 0) {
            player.setHealthMax(healthMax);
        } else {
            QueueProvider.offer("Maximum health must be possitive");
        }
    }


    public void command_health(String arg) {
        int health = Integer.parseInt(arg);
        if (health > 0) {
            player.setHealth(health);
        } else {
            QueueProvider.offer("Health must be possitive");
        }
    }
*/

    public void command_armour(String arg) {
        int armour = Integer.parseInt(arg);
        player.setArmour(armour);
    }


    public void command_level(String arg) {
        int level = Integer.parseInt(arg);
        player.setLevel(level);
    }


    public void command_gold(String arg) {
        int gold = Integer.parseInt(arg);
        player.setGold(gold);
    }

/*
    public void command_teleport(String arg) {
        LocationRepository locationRepo = GameBeans.getLocationRepository(player.getName());
        Current_Location newLocation = locationRepo.getLocation(new Coordinate(arg));
        Current_Location oldLocation = player.getLocation();
        try {
            player.setLocation(newLocation);
            player.getLocation().print();
        } catch (NullPointerException e) {
            player.setLocation(oldLocation);
            QueueProvider.offer("There is no such location");
        }
    }


    public void command_backpack(String arg) {
        new BackpackDebugPrompt(player);
    }


    public void command_talk(String arg) throws Death_Exception {
        ConversationManager cm = new ConversationManager();
        List<NPC> npcs = player.getLocation().getNpcs();
        NPC npc = null;
        for (NPC i : npcs) {
            if (i.getName().equalsIgnoreCase(arg)) {
                npc = i;
            }
        }
        if (npc != null) {
            cm.startConversation(npc, player);
        } else {
            QueueProvider.offer("Unable to talk to " + arg);
        }
    }
*/

    private void addItemToLocation() {
        Item_Repository itemRepo = GameBeans.getItemRepository();
        if (player.getHealth() < player.getHealthMax()/3) {
            player.getLocation().addItem(itemRepo.getRandomFood(player.getLevel()));
        } else {
            Random rand = new Random();
            int startIndex = rand.nextInt(3);
            switch (startIndex) {
                case 0:
                    player.getLocation().addItem(itemRepo.getRandomWeapon(player.getLevel()));
                    break;
                case 1:
                    player.getLocation().addItem(itemRepo.getRandomFood(player.getLevel()));
                    break;
                case 2:
                    player.getLocation().addItem(itemRepo.getRandomArmour(player.getLevel()));
                    break;
                case 3:
                    player.getLocation().addItem(itemRepo.getRandomPotion(player.getLevel()));
                    break;
            }
        }
    }
}
