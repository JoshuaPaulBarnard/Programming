package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Text_Checkers;

import edu.srjc.Barnard.Joshua.Final.Idle_game.UI_Controller;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class general_Checker extends UI_Controller
{
    @FXML
    public TextArea Primary_Console;



    public void check_General( String toCheck )
    {
        // Input Text, make lowercase.
        //String toCheck = "";
        //toCheck = pass_checkText;



        if( toCheck.contains( "hi" ) )
        {
            Primary_Console.appendText( "Hey." + "\n" + "Whats Up." + "\n" );
        }

    }

}
