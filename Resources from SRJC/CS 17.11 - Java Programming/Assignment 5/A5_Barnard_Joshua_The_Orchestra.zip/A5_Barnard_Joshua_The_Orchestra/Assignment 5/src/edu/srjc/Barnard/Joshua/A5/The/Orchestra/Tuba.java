/*
Joshua Paul Barnard
CS 17.11 - Java Programming
Assignment 5 - The Orchestra
Due: 03/09/2018

This is the Tuba class which extends the Brasswind class.
 */

package edu.srjc.Barnard.Joshua.A5.The.Orchestra;

public class Tuba extends Brasswind
{
    public Tuba()
    {
        this.setTransposition( false );
        this.setValves( 4 );
        this.setClef( Clef.Bass );
        this.setKey( Key.C );
    }
}
