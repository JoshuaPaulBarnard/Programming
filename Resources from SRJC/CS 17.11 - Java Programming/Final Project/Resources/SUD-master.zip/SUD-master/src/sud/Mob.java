//package sud;


class Mob extends Creature
{
        	
}

/*
   Need New Mob?
   
   (V) (°,,°) (V) 
   
   Why not Zoidberg?
   
    
 */