package edu.srjc.Gutierrez.Herbert.A8.Herbert.Gutierrez;

public class WeatherReading
{

}
