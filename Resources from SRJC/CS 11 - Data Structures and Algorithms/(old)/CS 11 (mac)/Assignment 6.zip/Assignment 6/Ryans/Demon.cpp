//
//  DemonImplementation.cpp
//  7_1
//
//  Created by Ryan  Martino on 10/29/17.
//  Copyright © 2017 Ryan  Martino. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include "Demon.h"
#include <string>

namespace cs_creature {
    Demon::Demon() : Creature()
    {
    }






    Demon::Demon(int newStrength, int newHitpoints)

    : Creature(newStrength, newHitpoints)
    {
    }






    std::string Demon::getSpecies() const
    {

        std::string species = "Demon";
        return species;
    }






    int Demon::getDamage() const
    {

        int damage;
        damage = Creature::getDamage();
        if (rand() % 4 == 0) {
            damage = damage + 50;
            std::cout << "Demonic attack inflicts 50 additional damage points!" << std::endl;
        }

        return damage;
    }
}
