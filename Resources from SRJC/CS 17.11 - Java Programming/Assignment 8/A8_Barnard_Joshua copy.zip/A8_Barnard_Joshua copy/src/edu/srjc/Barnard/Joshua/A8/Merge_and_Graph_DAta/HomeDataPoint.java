package edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers.Zero_Header_Reader;
import edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers.One_Header_Reader;
import edu.srjc.Barnard.Joshua.A8.Merge_and_Graph_DAta.Readers.Two_Header_Reader;


public class HomeDataPoint extends ArrayList<One_Header_Reader>
{


    public HomeDataPoint( String FileName, String Separator ) throws FileNotFoundException
    {
        Scanner InFile = new Scanner( new File( FileName ) );
        int count = 0;
        int header = 0;
        String line = "";

        while ( InFile.hasNextLine() )

        {
            line = InFile.nextLine().trim();
            count += 1;
            if ( count % 3 != 0 )
            {
                continue;
            }
            if ( line.length() == 0 || line.startsWith( "#" ) )
            {
                continue;
            }

            try
            {
                this.add( new One_Header_Reader( line, Separator ) );
            }
            catch ( Exception e )
            {
                System.out.println( String.format( "ERROR: %s, Ignoring This Field", e.getMessage() ) );
            }
        }
        Collections.reverse(this );

    }

}

