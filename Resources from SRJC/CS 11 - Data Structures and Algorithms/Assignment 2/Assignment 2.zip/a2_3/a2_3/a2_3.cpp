/*
Joshua Paul Barnard
CS 11 - SRJC
Spring 2017
Assignment 2 - 3
a2_3.cpp

This program receives an integer indicatingnumber of players in a game.
The program then call the initializeArrays function which creates 2 arrays
whose size is based on the number of players.
The user then inputs the name and value of a game score for each player.
The program will then call the sortData function to sort the data in descending order.
The program will then call the displayData function to output the data, showing
the top scores first with the lowerest score last.
*/

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

struct highScore
{
	int score;
	char name[24];
};

void initializeData( highScore scores[], int size );
void sortData( highScore scores[], int size );
void displayData( const highScore scores[], int size );

// Loop to initialize the struct
void initializeData( highScore scores[], int size )
{
	for ( int i = 0; i < size; i++ )
	{
		cout << "Enter the name for participant #" << i + 1 << ": \t";
		cin >> scores[i].name;
		cout << "Enter the score for participant #" << i + 1 << ": \t";
		cin >> scores[i].score;
	}
}

void sortData( highScore scores[], int size )
{
	for ( int i = 0; i < size - 1; ++i )
	{
		int min = i;
		for ( int index = i + 1; index < size; ++index )
		{
			if( scores[i].score.compare( scores[ index ].score ) < 0 )
			{
				min = index;
			}
		}
		if (min != i)
		{
			highScore temp = scores[i];
			scores[i] = scores[min];
			scores[min] = temp;
		}
	}
}


void displayData( const highScore scores[], int size )
{
	cout << "Top Scores:" << endl;
	for( int i = 0; i < size; i++ )
	{
		cout << scores[i].name << ": " << scores[i].score << endl;
	}
}


int main()
{
	int size = 0;

	cout << "How many scores will you enter?: \t";
	cin >> size;

	highScore scores[size];

	initializeData( scores[], size );
	sortData( scores[], size );
	displayData( scores[], size );

	return 0;
}
