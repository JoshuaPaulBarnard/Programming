/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Entities;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonArray;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonElement;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonObject;
import edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.gson.JsonParser;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Items.Storage;



/**
 * This class deals with Non Player Character (NPC) and all of their properties.
 * Any method that changes a NPC or a player  interacts with it should
 * be placed within this class. If a method deals with entities in general or
 * with variables not unique to the NPC, place it in the entity class.
 */
public class NPC extends Entity
{
    private int xpGain;
    private String id;
    private List<String> allies;
    private List<String> enemies;

    public NPC()
    {
    }

    public NPC(String entityID) {
        allies = new ArrayList<>();
        enemies = new ArrayList<>();
        this.id = entityID;
    }

    public void setItems(JsonObject json, int itemLimit, int i) {
        JsonArray items = json.get("items").getAsJsonArray();
        JsonArray itemTypes = json.get("tradingEmphasis").getAsJsonArray();
        boolean cont;
        for (JsonElement item : items) {
            if (i == itemLimit) {
                break;
            }

            cont = false;
            char itemType = item.getAsString().charAt(0);
            for (JsonElement type : itemTypes) {
                if (itemType == type.getAsString().charAt(0)) {
                    cont = true;
                }
            }

            Random rand = new Random();
            int j = rand.nextInt(100) + 1;
            if (cont) {
                if ((j > 0) && (j <= 95)) {
                    addItemToStorage(itemRepo.getItem(item.getAsString()));
                    i++;
                }
            } else {
                if ((j > 95) && (j <= 100)) {
                    addItemToStorage(itemRepo.getItem(item.getAsString()));
                    i++;
                }
            }
        }
        if (i != itemLimit) {
            setItems(json, itemLimit, i);
        }
    }

    public List<String> getAllies() {
        return allies;
    }

    public List<String> getEnemies() {
        return enemies;
    }

    public void setAllies( List<String> allies ) {
        this.allies = allies;
    }

    public void setEnemies( List<String> enemies ) {
        this.enemies = enemies;
    }

    public int getXPGain() {
        return xpGain;
    }

    public void setXPGain(int xpGain) {
        this.xpGain = xpGain;
    }

    public String getId() {
        return id;
    }


    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof NPC) {
            NPC npc = (NPC) obj;
            return npc.getId().equals(id);
        }
        return false;
    }


}
