/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github.
 *  https://github.com/Progether/JAdventure
 */



package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Enemies;

/*
 * A monster that is pretty easy to deal with.
 */
public class Skeleton extends Enemy {
    public Skeleton(int playerLevel){
        this.enemyType = "Skeleton";
        this.setHealthMax(50 + (int) Math.pow(playerLevel, 3));
        this.setHealth(50 + (int) Math.pow(playerLevel, 3));
        this.setArmour(0);
        this.setDamage(8 + Math.pow(playerLevel, 1.5));
        this.setCritChance(0.02);
        this.setIntelligence(3);
        this.setStealth(1);
        this.setDexterity(3);
        this.setXPGain(10 + playerLevel * 3);
        this.setGold(playerLevel * 3);
        addRandomItems(playerLevel, "arhl1");
    }
}

