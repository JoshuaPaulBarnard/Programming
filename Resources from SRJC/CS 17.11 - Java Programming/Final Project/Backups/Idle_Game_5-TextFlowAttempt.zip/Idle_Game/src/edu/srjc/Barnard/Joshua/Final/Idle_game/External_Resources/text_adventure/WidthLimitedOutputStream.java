package edu.srjc.Barnard.Joshua.Final.Idle_game.External_Resources.text_adventure;

import java.io.*;
import java.util.StringTokenizer;

//
//
// WidthLimitedOutputStream
//
// A width limited output stream provides a string
// printing method that will automatically insert
// line breaks, wrapping text to the next line.
//
// Last modification date : November 13, 1997
//
public class WidthLimitedOutputStream
{
    // Output stream
    private PrintStream out;
    private int width;

    // WidthLimitedOutputStream constructor
    public WidthLimitedOutputStream ( OutputStream out, int width )
    {
        out = new PrintStream (out);
        this.width = width;
    }

    /** string printing method that will automatically insert
     line breaks. */
    public void print ( String str )
    {
        // Start at zero
        int currentWidth = 0;

        // Create a string tokenizer object
        StringTokenizer tokenizer = new StringTokenizer ( str );

        // While words remain
        while ( tokenizer.hasMoreTokens() )
        {
            // Get the next token
            String token = tokenizer.nextToken();

            // If word would exceed width limit
            if (currentWidth + token.length() >= width)
            {
                // Print a newline
                out.println ();
                currentWidth = 0;
            }

            // Print token
            out.print (token + " ");

            currentWidth += token.length();
        }
        out.flush();
    }

    /** string printing method that will automatically insert
     line breaks. The println version appends a newline. */
    public void println (String str )
    {
        print (str);
        out.println();
    }

    /** Prints a blank line */
    public void println ()
    {
        out.println();
    }
}


