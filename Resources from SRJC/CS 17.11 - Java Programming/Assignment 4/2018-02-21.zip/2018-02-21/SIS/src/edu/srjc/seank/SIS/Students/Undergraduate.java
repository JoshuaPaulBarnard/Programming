package edu.srjc.seank.SIS.Students;

import edu.srjc.seank.SIS.AgeGreaterThan125Exception;
import edu.srjc.seank.SIS.AgeLessThanZeroException;

public class Undergraduate extends Student
{
    private String major;
    private String minor;

    public Undergraduate(String firstName, String lastName, String address, String city, String state, String zip, int age, String id) throws AgeLessThanZeroException, AgeGreaterThan125Exception
    {
        super(firstName, lastName, address, city, state, zip, age, id);
    }

    public String getMajor()
    {
        return major;
    }

    public void setMajor(String major)
    {
        this.major = major;
    }

    public String getMinor()
    {
        return minor;
    }

    public void setMinor(String minor)
    {
        this.minor = minor;
    }
}
