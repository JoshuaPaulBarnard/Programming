package edu.srjc.seank.Person;


public class Main {

    public static void main(String[] args) {

        Person p = null;
        try
        {
            p = new Person("Will", "here", "Santa Rosa", 1963);
        }
        catch (Exception ex)
        {
            System.out.println(String.format("an error occurred %s", ex.getMessage()));
            System.exit(0);
        }

        System.out.println(String.format("Hello %s", p.toString()));


    }

}














