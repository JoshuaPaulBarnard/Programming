/*
 * 
 */
package game;

public class Config {
	public static boolean DEBUG = false;
}
