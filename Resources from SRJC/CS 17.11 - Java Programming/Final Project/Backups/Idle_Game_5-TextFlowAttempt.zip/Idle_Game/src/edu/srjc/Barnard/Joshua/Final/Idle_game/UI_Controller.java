/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: Idle Game
 *
 *  Code Disclaimer:
 *  All code in this file is original.
 *
 */
package edu.srjc.Barnard.Joshua.Final.Idle_game;


import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Player.Player;
import javafx.scene.text.TextFlow;

/**
 *
 * @author JoshuaPaulBarnard
 */
public class UI_Controller implements Initializable
{
    // Basic UI Handlers
    @FXML
    public Text HP_Current;

    @FXML
    public Text HP_Max;

    @FXML
    public Text WP_Current;

    @FXML
    public Text WP_Max;

    @FXML
    public TextArea Status_Display;

    @FXML
    public TextArea Inventory_Display;

    @FXML
    public TextArea Equipment_Display;

    @FXML
    public TextArea Crafting_Display;

    @FXML
    public TextArea Skills_Display;

    @FXML
    public TextArea Map;

    @FXML
    public TextFlow Primary_Console;

    @FXML
    public TextField Text_Input;

    @FXML
    public TextArea Events_Log;

    @FXML
    public TextArea Story_Log;

    @FXML
    public TextArea Class_Log;

    @FXML
    public TextArea Skills_Log;

    @FXML
    public TextArea Combat_Log;

    @FXML
    public TextArea Extra_Log;


    // Basic game control functions
    @FXML
    private void Game_Exit(  )
    {
        Platform.exit();
        System.exit(0 );
    }

    @FXML
    private void Game_Save(  )
    {

    }

    @FXML
    private void Game_Loud(  )
    {

    }

    @FXML
    private void Game_Copy(  )
    {

    }

    @FXML
    private void Game_Paste(  )
    {

    }

    @FXML
    private void Game_Delete(  )
    {

    }

    @FXML
    private void Game_Help(  )
    {

    }

    @FXML
    private void Game_Feedback(  )
    {

    }

    @FXML
    private void Game_About(  )
    {

    }

    private int beginning_step = 1;

    private boolean isChangeName = false;
    private boolean isChangeGender = false;
    private boolean isChangeClass = false;
    private boolean isChangeColour = false;
    private boolean isGameRunning = false;



    // Event handler for the user pressing enter or clicking the submitButton.
    @FXML
    public void inputTextHandler( ActionEvent event )
    {
        // inputText is for passing the users text into the primary console, unmodified.
        // checkText is converted to lowercase and used for checking for game commands.
        String inputText = "";
        inputText = Text_Input.getText();

        String checkText = "";
        checkText = Text_Input.getText().toLowerCase();

        Color textColour_User = Color.BLACK;
        Text display_inputText = new Text();

        Color textColour_Event = Color.BLACK;
        Text display_eventText = new Text();



// Create text variables and apply formatting
    display_inputText.setText( Player.playersName + ": " + inputText + "\n" );
    display_inputText.setFill( textColour_User );
    Primary_Console.getChildren().addAll( display_inputText );



// Beginning Sequence
        if( isChangeName == true )
        {
            if( Player.playersName.equals( "" ) && Text_Input.getText().equals( "" ) )
            {
                display_eventText.setText( "Error:  Please Re-enter Name\n" );
                display_eventText.setFill( textColour_Event );
                Primary_Console.getChildren().addAll( display_eventText );
            }
            else
            {
                Player.playersName = Text_Input.getText();
                isChangeName = false;
                beginning_step = 3;
            }
        }

        if( isChangeGender == true )
        {
            if( checkText.contains( "female" ) )
            {
                Player.isMale = false;
                isChangeGender = false;
                beginning_step = 4;
            }
            else if( checkText.contains( "male" ) )
            {
                Player.isMale = true;
                isChangeGender = false;
                beginning_step = 4;
            }
        }

        if( isChangeClass == true )
        {
            if( checkText.contains( "initiate" ) )
            {
                Player.playersClass = "Initiate";
                isChangeClass = false;
                beginning_step = 5;
            }
            if( checkText.contains( "military" ) || checkText.contains( "operative" ) )
            {
                Player.playersClass = "Military Operative";
                isChangeClass = false;
                beginning_step = 5;
            }
            if( checkText.contains( "vagabond" ) )
            {
                Player.playersClass = "Vagabond";
                isChangeClass = false;
                beginning_step = 5;
            }
        }

        if( isChangeColour == true )
        {
            if( checkText.contains( "black" ) )
            {
                Player.playersColour = "Black";
                textColour_User = Color.BLACK;

                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "red" ) )
            {
                Player.playersColour = "Red";
                textColour_User = Color.RED;

                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "orange" ) )
            {
                Player.playersColour = "Orange";
                textColour_User = Color.ORANGE;

                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "yellow" ) )
            {
                Player.playersColour = "Yellow";
                textColour_User = Color.YELLOW;

                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "green" ) )
            {
                Player.playersColour = "Green";
                textColour_User = Color.GREEN;

                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "blue" ) )
            {
                Player.playersColour = "Blue";
                textColour_User = Color.BLUE;

                isChangeColour = false;
                beginning_step = 6;
            }
            if( checkText.contains( "purple" ) )
            {
                Player.playersColour = "Purple";
                textColour_User = Color.PURPLE;

                isChangeColour = false;
                beginning_step = 6;
            }
        }

// Clear TextField
        Text_Input.clear();

// Check if it is the beginning sequence
        beginning_Sequence();

// Pass the users input text to functions which will check for keywords
        checkText_General( checkText );
        checkText_Combat( checkText );
        checkText_Skills( checkText );
        checkText_Class( checkText );
        checkText_Special( checkText );
    }


    
    public void beginning_Sequence(  )
    {

        // Text Constructors
        Color textColour_Beginning = Color.BLACK;
        Text display_BeginningText = new Text();

        // Intro Sequence
        if( beginning_step == 1 )
        {
            display_BeginningText.setText
                    (
                    "Welcome to my JavaFX Idle Text Game Template!\n" +
                            "__________________________________________________\n" +
                            "\n"
                    );
            display_BeginningText.setFill( Color.GREEN );
            Primary_Console.getChildren().addAll( display_BeginningText );

            beginning_step = 2;
        }

        // Name Enterance Sequence
        if( beginning_step == 2 )
        {
            isChangeName = true;

            display_BeginningText.setText(
                    "Please Enter Your Name:\n"
            );
            display_BeginningText.setFill( textColour_Beginning );
            Primary_Console.getChildren().addAll( display_BeginningText );
        }

        // Gender Choice Sequence
        if( beginning_step == 3 )
        {
            isChangeGender = true;

            display_BeginningText.setText(
                    "What Gender Are you?\n" +
                            "Male\n" +
                            "Female\n"
            );
            display_BeginningText.setFill( textColour_Beginning );
            Primary_Console.getChildren().addAll( display_BeginningText );
        }

        // Class Choice Sequence
        if( beginning_step == 4 )
        {
            isChangeClass = true;

            display_BeginningText.setText(
                    "What is your class?\n" +
                            "Initiate\n" +
                            "Military Operative\n" +
                            "Vagabond\n"
            );
            display_BeginningText.setFill( textColour_Beginning );
            Primary_Console.getChildren().addAll( display_BeginningText );
        }

        // Players Favorite Color Choice Sequence
        if( beginning_step == 5 )
        {
            isChangeColour = true;

            display_BeginningText.setText(
                    "What is your favorite colour?\n" +
                            "Red\n" +
                            "Yellow\n" +
                            "Orage\n" +
                            "Green\n" +
                            "Blue\n" +
                            "Purple\n" +
                            "Black\n"
            );
            display_BeginningText.setFill( textColour_Beginning );
            Primary_Console.getChildren().addAll( display_BeginningText );
        }

        // Beginning Game Sequence
        if( beginning_step == 6 )
        {
            display_BeginningText.setText(
                    "Thank you for your choices!\n" +
                            "Enjoy The Game!!\n" +
                            "\n"
            );
            display_BeginningText.setFill( textColour_Beginning );
            Primary_Console.getChildren().addAll( display_BeginningText );

            beginning_step = 0;
        }

        // Play the Game
        if( beginning_step == 0 )
        {
            isGameRunning = true;
            game_Start();
        }

    }






//---------------------------------------------------- Start Text Checkers ------------------------------------------------------------------------------

    public void checkText_General( String CheckText )
    {

        // Check input for game commands
        if( CheckText.equals( "quit" ) )
        {
            Game_Exit();
        }
        if( CheckText.equals( "save" ) )
        {
            Game_Save();
        }
        if( CheckText.equals( "load" ) )
        {
            Game_Loud();
        }

        //Check for Directions
        if( CheckText.equals( "up" ) )
        {

        }
        if( CheckText.equals( "down" ) )
        {

        }
        if( CheckText.equals( "left" ) )
        {

        }
        if( CheckText.equals( "right" ) )
        {

        }
        if( CheckText.equals( "north" ) )
        {

        }
        if( CheckText.equals( "south" ) )
        {

        }
        if( CheckText.equals( "east" ) )
        {

        }
        if( CheckText.equals( "west" ) )
        {

        }
        if( CheckText.contains( "autowanderning" ) && CheckText.contains( "on" ) )
        {

        }
        if( CheckText.contains( "autowanderning" ) && CheckText.contains( "off" ) )
        {

        }
    }

    public void checkText_Combat( String CheckText )
    {

    }

    public void checkText_Skills( String CheckText )
    {

    }

    public void checkText_Class( String CheckText )
    {

    }

    public void checkText_Special( String CheckText )
    {

    }

//----------------------------------------------------- End Text Checkers -------------------------------------------------------------------------------



    public void game_Start(  )
    {

    }



    @Override
    public void initialize( URL url, ResourceBundle rb )
    {
        // TODO
        beginning_Sequence();
    }    

}
