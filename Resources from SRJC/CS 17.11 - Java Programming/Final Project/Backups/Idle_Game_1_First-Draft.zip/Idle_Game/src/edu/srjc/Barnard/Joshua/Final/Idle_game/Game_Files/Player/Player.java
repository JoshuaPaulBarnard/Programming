package edu.srjc.Barnard.Joshua.Final.Idle_game.Game_Files.Player;

public class Player
{
    // Players Information
    protected String playersName = "";
    protected boolean isMale = true;
    protected String playersClass = "";

    // Players Statistics
    protected int HealthPoints = 0;
    protected int WillPoints = 0;
    protected int ExperiencePoints = 0;
    protected int playersLevel = 0;

    // Players Attributes
    protected int Courage = 0;
    protected int Resolve = 0;
    protected int Stamina = 0;
    protected int Resilience = 0;
    protected int Charisma = 0;
    protected int Presense = 0;
    protected int Perception = 0;
    protected int Sense = 0;
    protected int Agility = 0;
    protected int Reflexes = 0;
    protected int Intelligence = 0;
    protected int Knowledge = 0;
    protected int Wisdom = 0;
    protected int Will = 0;
    protected int Psyche = 0;



}
