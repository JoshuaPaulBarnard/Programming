/*
 *  Name:        Joshua Paul Barnard
 *  Class:       CS 17.11 - Java Programming
 *  Location:    Santa Rosa Junior College
 *  Assignment:  Final Project
 *
 *  Description: JFX IdleAdventure Game
 *
 *  Code Disclaimer:
 *  This code is highly derivative from the JAdventure project on Github
 *  https://github.com/Progether/JAdventure
 */




package edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure;


import java.util.ArrayList;

import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Entities.Player;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Enemies.Enemy;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Enemies.Enemy_Factory;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Repository.Location_Repository;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Text_Handling.QueueProvider;
import edu.srjc.Barnard.Joshua.Final.Idle_game.JFX_IdleAdventure.Text_Handling.InputText_Parser;


/**
 * This class contains the main loop that takes the input and
 * does the according actions.
 */
public class Game 
{
    public ArrayList<Enemy> monsterList = new ArrayList<Enemy>();
    public Enemy_Factory Enemy_Factory = new Enemy_Factory();
    public InputText_Parser parser;
    public Enemy enemy;
    Player player = null;

    public Game(Player player, String playerType) throws Death_Exception
    {
        this.parser = new InputText_Parser(player);
        this.player = player;
        switch (playerType) {
            case "new":
                newGameStart(player);
                break;
            case "old":
                QueueProvider.offer("Welcome back, " + player.getName() + "!");
                QueueProvider.offer("");
                player.getLocation().print();
                //gamePrompt(player);
                break;
            default:
                QueueProvider.offer("Invalid player type");
                break;
        }
    }

    /**
     * Starts a new game.
     * It prints the introduction text first and asks for the name of the player's
     * character and welcomes him / her. After that, it goes to the normal game prompt.
     */
    public void newGameStart(Player player) throws Death_Exception
    {
        QueueProvider.offer(player.getIntro());
        String userInput = QueueProvider.take();
        player.setName(userInput);
        Location_Repository locationRepo = GameBeans.getLocationRepository(player.getName());
        this.player.setLocation(locationRepo.getInitialLocation());
        player.save();
        QueueProvider.offer("Welcome to Silliya, " + player.getName() + ".");
        player.getLocation().print();
        //gamePrompt(player);
    }

    /**
     * This is the main loop for the player-game interaction. It gets input from the
     * command line and checks if it is a recognised command.
     *
     * This keeps looping as long as the player didn't type an exit command.
     */

    /*
    public void gamePrompt(Player player) throws Death_Exception
    {
        boolean continuePrompt = true;
        try
        {
            while (continuePrompt)
            {

            }
        }
        catch ( Death_Exception e) {
            if (e.getLocalisedMessage().equals("replay"))
            {
                return;
            }
            else
                {
                throw e;
            }
        }
    }
    */
}
