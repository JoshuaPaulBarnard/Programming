package adventure;

public class Actor extends Thing {

  public Actor(String name) {
    super(name);
  }
  
  public Actor(String name, String description) {
    super(name, description);
  }

}
